import React from 'react';
import { Search, SlidersHorizontal, Grid, List } from 'lucide-react';
import { CategoryType } from '../../types';

interface ProductFilterBarProps {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedCategory: CategoryType;
  setSelectedCategory: (cat: CategoryType) => void;
  sortBy: string;
  setSortBy: (sort: string) => void;
  maxPrice: number;
  setMaxPrice: (price: number) => void;
  viewMode: 'grid' | 'list';
  setViewMode: (mode: 'grid' | 'list') => void;
}

export const ProductFilterBar: React.FC<ProductFilterBarProps> = ({
  searchQuery,
  setSearchQuery,
  selectedCategory,
  setSelectedCategory,
  sortBy,
  setSortBy,
  maxPrice,
  setMaxPrice,
  viewMode,
  setViewMode,
}) => {
  const categories: { label: string; value: CategoryType }[] = [
    { label: 'ALL MUSHROOMS', value: 'ALL' },
    { label: 'PEARL OYSTER', value: 'OYSTER' },
    { label: 'WHITE BUTTON', value: 'BUTTON' },
    { label: 'SUMMER MILKY', value: 'MILKY' },
    { label: 'EXOTIC SPECIALTY', value: 'SPECIALTY' },
    { label: 'GOURMET MIXES', value: 'MIX' },
  ];

  return (
    <div className="bg-cream-100/90 rounded-3xl p-6 border border-cream-200 shadow-organic mb-10 space-y-6">
      {/* SEARCH BAR & SORT & VIEW TOGGLE */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        {/* SEARCH INPUT */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-earth-700 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search Oyster, Button, Milky..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-full border border-cream-300 bg-cream-50 text-xs font-sans text-earth-900 placeholder:text-earth-700/50 focus:outline-none focus:border-forest-900 shadow-sm"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs text-earth-700 hover:text-earth-900"
            >
              Clear
            </button>
          )}
        </div>

        {/* SORT & VIEW CONTROLS */}
        <div className="flex items-center gap-4 w-full md:w-auto justify-between md:justify-end">
          {/* PRICE SLIDER */}
          <div className="flex items-center gap-2 text-xs font-mono text-earth-800">
            <span>Max Price:</span>
            <input
              type="range"
              min="100"
              max="500"
              step="20"
              value={maxPrice}
              onChange={(e) => setMaxPrice(Number(e.target.value))}
              className="w-24 accent-forest-900"
            />
            <span className="font-bold text-forest-950">₹{maxPrice}</span>
          </div>

          {/* SORT DROPDOWN */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="px-3.5 py-2.5 rounded-full border border-cream-300 bg-cream-50 text-xs font-semibold text-earth-900 focus:outline-none focus:border-forest-900 cursor-pointer"
          >
            <option value="featured">Featured First</option>
            <option value="price-low">Price: Low to High</option>
            <option value="price-high">Price: High to Low</option>
            <option value="rating">Highest Rated</option>
          </select>

          {/* GRID / LIST TOGGLE */}
          <div className="hidden sm:flex items-center border border-cream-300 rounded-full bg-cream-50 p-1">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-full transition-colors ${
                viewMode === 'grid' ? 'bg-forest-900 text-cream-50' : 'text-earth-700 hover:text-earth-900'
              }`}
              aria-label="Grid view"
            >
              <Grid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-1.5 rounded-full transition-colors ${
                viewMode === 'list' ? 'bg-forest-900 text-cream-50' : 'text-earth-700 hover:text-earth-900'
              }`}
              aria-label="List view"
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* CATEGORY TABS */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pt-2 border-t border-cream-200">
        {categories.map((cat) => (
          <button
            key={cat.value}
            onClick={() => setSelectedCategory(cat.value)}
            className={`px-4 py-2 rounded-full text-xs font-semibold uppercase tracking-wider whitespace-nowrap transition-all ${
              selectedCategory === cat.value
                ? 'bg-forest-900 text-golden-400 shadow-md border border-golden-500/30'
                : 'bg-cream-50 text-earth-800 hover:bg-cream-200 border border-cream-200'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>
    </div>
  );
};
