import React from 'react';
import { Link } from 'react-router-dom';
import { Sprout, ShieldCheck, Heart, Award, ArrowRight, User, MapPin, Phone } from 'lucide-react';
import { SporeParticles } from '../components/common/SporeParticles';

export const AboutPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-cream-50 text-earth-900 pt-24 pb-24">
      {/* HERO BANNER */}
      <section className="relative bg-forest-950 text-cream-50 py-24 overflow-hidden mb-16 border-b border-golden-500/20">
        <SporeParticles density={35} speed={1} />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center space-y-4">
          <div className="w-24 h-24 mx-auto rounded-full border-2 border-golden-500/60 p-1 bg-forest-900 shadow-golden-glow overflow-hidden">
            <img src="/assets/logo.jpg" alt="Baba Ji Logo" className="w-full h-full object-cover rounded-full" />
          </div>
          <span className="text-xs font-mono font-bold text-golden-400 tracking-widest uppercase">
            VARANASI, UTTAR PRADESH • EST. 1978
          </span>
          <h1 className="font-serif text-4xl sm:text-6xl font-bold tracking-tight text-cream-50">
            ABOUT BABA JI FARMS
          </h1>
          <p className="text-sm sm:text-base text-cream-200/80 max-w-2xl mx-auto font-sans leading-relaxed">
            Founded by <strong className="text-cream-50">Abhay Jaiswal</strong>, Baba Ji Farms bridges traditional organic farming with precision climate control in Varanasi, Uttar Pradesh.
          </p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-20">
        {/* STORY & PHILOSOPHY */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-6 space-y-6">
            <span className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-forest-100 text-forest-900 text-xs font-semibold uppercase font-mono">
              <Sprout className="w-4 h-4 text-forest-700" />
              ABHAY JAISWAL'S VISION
            </span>
            <h2 className="font-serif text-3xl sm:text-5xl font-bold text-forest-950 leading-tight">
              PURE ORGANIC CULTIVATION IN VARANASI
            </h2>
            <p className="text-sm sm:text-base text-earth-800/90 leading-relaxed font-sans">
              Under the leadership of founder <strong className="text-forest-950">Abhay Jaiswal</strong>, Baba Ji Farms operates with zero synthetic pesticides and 100% natural substrate casing.
            </p>
            <p className="text-sm sm:text-base text-earth-800/90 leading-relaxed font-sans">
              Our automated misting chambers maintain 88% mountain mist humidity, harvesting Pearl Oyster, White Button, and Summer Milky mushrooms fresh every morning.
            </p>

            <div className="p-4 bg-cream-100 rounded-2xl border border-cream-300 font-mono text-xs text-forest-950 space-y-1">
              <p><strong>Owner & Master Grower:</strong> Abhay Jaiswal</p>
              <p><strong>Farm Location:</strong> Varanasi, Uttar Pradesh, India</p>
              <p><strong>Mobile / WhatsApp:</strong> +91 91400 37160</p>
            </div>
          </div>

          <div className="lg:col-span-6">
            <div className="rounded-3xl overflow-hidden shadow-2xl border-4 border-cream-200 aspect-video sm:aspect-[4/3]">
              <img src="/assets/hero.jpg" alt="Baba Ji Chamber" className="w-full h-full object-cover" />
            </div>
          </div>
        </div>

        {/* 4 CORE VALUES */}
        <div className="bg-cream-100 rounded-3xl p-8 sm:p-12 border border-cream-200 shadow-organic space-y-8">
          <div className="text-center max-w-2xl mx-auto">
            <h3 className="font-serif text-3xl font-bold text-forest-950">WHAT MAKES US DIFFERENT</h3>
            <p className="text-xs text-earth-700 font-mono mt-2 uppercase tracking-widest">
              Abhay Jaiswal's 4 Pillars of Quality
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="p-6 bg-cream-50 rounded-2xl border border-cream-200 space-y-3">
              <ShieldCheck className="w-8 h-8 text-forest-700" />
              <h4 className="font-serif font-bold text-lg text-forest-950">Zero Chemical Sprays</h4>
              <p className="text-xs text-earth-800/80 leading-relaxed">Protected purely through HEPA air filtration and strict biosecurity protocols.</p>
            </div>
            <div className="p-6 bg-cream-50 rounded-2xl border border-cream-200 space-y-3">
              <Sprout className="w-8 h-8 text-forest-700" />
              <h4 className="font-serif font-bold text-lg text-forest-950">Organic Substrate</h4>
              <p className="text-xs text-earth-800/80 leading-relaxed">Steamed wheat straw and mineral casing enriched with organic nutrients.</p>
            </div>
            <div className="p-6 bg-cream-50 rounded-2xl border border-cream-200 space-y-3">
              <Heart className="w-8 h-8 text-forest-700" />
              <h4 className="font-serif font-bold text-lg text-forest-950">Dawn Hand Harvesting</h4>
              <p className="text-xs text-earth-800/80 leading-relaxed">Gently picked at first light when moisture retention is highest.</p>
            </div>
            <div className="p-6 bg-cream-50 rounded-2xl border border-cream-200 space-y-3">
              <Award className="w-8 h-8 text-forest-700" />
              <h4 className="font-serif font-bold text-lg text-forest-950">Sustainable Packaging</h4>
              <p className="text-xs text-earth-800/80 leading-relaxed">Packed in breathable kraft containers that keep mushrooms fresh without plastic sweating.</p>
            </div>
          </div>
        </div>

        {/* FINAL SHOP CTA */}
        <div className="bg-forest-950 text-cream-50 rounded-3xl p-8 sm:p-12 text-center space-y-6 relative overflow-hidden">
          <SporeParticles density={20} speed={1} />
          <h3 className="font-serif text-3xl sm:text-4xl font-bold tracking-tight text-cream-50 relative z-10">
            EXPERIENCE THE FRESHNESS OF BABA JI FARMS
          </h3>
          <p className="text-xs sm:text-sm text-cream-200/80 max-w-xl mx-auto font-sans relative z-10">
            Order fresh Pearl Oyster, White Button, or Gourmet Mixes directly from Abhay Jaiswal's Varanasi farm today.
          </p>
          <div className="relative z-10 pt-2">
            <Link
              to="/store"
              className="inline-flex items-center gap-2 px-8 py-4 rounded-full bg-golden-500 hover:bg-golden-400 text-forest-950 font-bold text-xs uppercase tracking-widest shadow-golden-glow transition-all"
            >
              <span>SHOP FRESH MARKETPLACE</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>

      </div>
    </div>
  );
};
