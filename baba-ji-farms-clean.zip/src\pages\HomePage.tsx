import React from 'react';
import { HeroSection } from '../components/home/HeroSection';
import { BrandIntro } from '../components/home/BrandIntro';
import { WhyBabaJi } from '../components/home/WhyBabaJi';
import { FeaturedProducts } from '../components/home/FeaturedProducts';
import { ProcessSection } from '../components/home/ProcessSection';
import { FarmStorySection } from '../components/home/FarmStorySection';
import { QualitySection } from '../components/home/QualitySection';
import { TestimonialsSection } from '../components/home/TestimonialsSection';
import { FinalCTA } from '../components/home/FinalCTA';

export const HomePage: React.FC = () => {
  return (
    <main className="w-full overflow-hidden">
      <HeroSection />
      <BrandIntro />
      <WhyBabaJi />
      <FeaturedProducts />
      <ProcessSection />
      <FarmStorySection />
      <QualitySection />
      <TestimonialsSection />
      <FinalCTA />
    </main>
  );
};
