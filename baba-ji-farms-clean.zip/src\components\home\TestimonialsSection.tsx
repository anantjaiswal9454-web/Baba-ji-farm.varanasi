import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { SectionHeading } from '../common/SectionHeading';
import { MOCK_REVIEWS } from '../../data/reviews';
import { Star, Quote, ChevronLeft, ChevronRight, CheckCircle2 } from 'lucide-react';

export const TestimonialsSection: React.FC = () => {
  const [currentIdx, setCurrentIdx] = useState(0);

  const handleNext = () => {
    setCurrentIdx((prev) => (prev + 1) % MOCK_REVIEWS.length);
  };

  const handlePrev = () => {
    setCurrentIdx((prev) => (prev - 1 + MOCK_REVIEWS.length) % MOCK_REVIEWS.length);
  };

  const current = MOCK_REVIEWS[currentIdx];

  return (
    <section className="py-24 bg-cream-100/80 relative overflow-hidden">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <SectionHeading
          eyebrow="CUSTOMER LOVE"
          title="WHAT OUR COMMUNITY SAYS"
          subtitle="Read real stories from home cooks, chefs, and health enthusiasts who love Baba Ji Farms mushrooms."
          theme="light"
        />

        {/* TESTIMONIAL DISPLAY BOARD */}
        <div className="relative mt-12 bg-cream-50 rounded-3xl p-8 sm:p-12 shadow-organic-lg border border-cream-200">
          <Quote className="absolute top-6 right-6 w-16 h-16 text-forest-900/10 pointer-events-none" />

          <AnimatePresence mode="wait">
            <motion.div
              key={current.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.4 }}
              className="space-y-6"
            >
              {/* RATING STARS */}
              <div className="flex items-center gap-1">
                {Array.from({ length: current.rating }).map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-golden-500 text-golden-500" />
                ))}
              </div>

              {/* COMMENT */}
              <p className="font-serif text-xl sm:text-2xl text-forest-950 font-medium leading-relaxed italic">
                "{current.comment}"
              </p>

              {/* AUTHOR INFO */}
              <div className="flex items-center justify-between pt-6 border-t border-cream-200">
                <div>
                  <h4 className="font-serif font-bold text-lg text-forest-950 flex items-center gap-2">
                    {current.userName}
                    {current.verifiedBuyer && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-forest-100 text-forest-900 text-[10px] font-mono font-semibold">
                        <CheckCircle2 className="w-3 h-3 text-forest-700" /> Verified Buyer
                      </span>
                    )}
                  </h4>
                  <p className="text-xs text-earth-700 font-mono mt-0.5">
                    {current.location} • Purchased {current.productName}
                  </p>
                </div>

                {/* CAROUSEL BUTTONS */}
                <div className="flex items-center gap-2">
                  <button
                    onClick={handlePrev}
                    className="p-3 rounded-full bg-cream-200 hover:bg-forest-900 hover:text-cream-50 text-forest-950 transition-colors shadow-sm"
                    aria-label="Previous review"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </button>
                  <button
                    onClick={handleNext}
                    className="p-3 rounded-full bg-cream-200 hover:bg-forest-900 hover:text-cream-50 text-forest-950 transition-colors shadow-sm"
                    aria-label="Next review"
                  >
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* DOT INDICATORS */}
          <div className="flex justify-center items-center gap-2 mt-8">
            {MOCK_REVIEWS.map((r, idx) => (
              <button
                key={r.id}
                onClick={() => setCurrentIdx(idx)}
                className={`h-2 rounded-full transition-all ${
                  currentIdx === idx ? 'w-8 bg-forest-900' : 'w-2 bg-cream-300'
                }`}
                aria-label={`Go to slide ${idx + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
