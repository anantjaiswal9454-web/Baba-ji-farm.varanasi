import React from 'react';
import { motion } from 'framer-motion';

interface SectionHeadingProps {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  centered?: boolean;
  theme?: 'dark' | 'light';
}

export const SectionHeading: React.FC<SectionHeadingProps> = ({
  eyebrow,
  title,
  subtitle,
  centered = true,
  theme = 'light',
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className={`max-w-3xl mb-12 ${centered ? 'mx-auto text-center' : ''}`}
    >
      {eyebrow && (
        <span
          className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-widest mb-4 ${
            theme === 'dark'
              ? 'bg-forest-800/80 text-golden-500 border border-golden-500/20'
              : 'bg-forest-100 text-forest-900 border border-forest-500/20'
          }`}
        >
          <span className="w-1.5 h-1.5 rounded-full bg-golden-500 animate-pulse" />
          {eyebrow}
        </span>
      )}
      <h2
        className={`text-3xl md:text-5xl font-serif font-bold tracking-tight leading-tight ${
          theme === 'dark' ? 'text-cream-50' : 'text-forest-950'
        }`}
      >
        {title}
      </h2>
      {subtitle && (
        <p
          className={`mt-4 text-base md:text-lg leading-relaxed ${
            theme === 'dark' ? 'text-cream-200/80' : 'text-earth-800/80'
          }`}
        >
          {subtitle}
        </p>
      )}
    </motion.div>
  );
};
