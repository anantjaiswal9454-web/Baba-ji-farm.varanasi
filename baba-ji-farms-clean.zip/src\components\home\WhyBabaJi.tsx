import React from 'react';
import { motion } from 'framer-motion';
import { SectionHeading } from '../common/SectionHeading';
import { Sprout, Sun, HeartPulse, PackageCheck } from 'lucide-react';

export const WhyBabaJi: React.FC = () => {
  const benefits = [
    {
      num: '01',
      title: 'FARM FRESH',
      tagline: 'Harvested with freshness in mind.',
      desc: 'Harvested twice daily at early morning light to preserve moisture content and pristine cell structure.',
      icon: Sprout,
      bg: 'bg-forest-900 text-cream-50',
      accent: 'border-golden-500/30',
    },
    {
      num: '02',
      title: 'NATURALLY GROWN',
      tagline: 'Carefully cultivated from farm to harvest.',
      desc: 'Nurtured in pure organic substrate mixtures without artificial growth boosters or synthetic pesticides.',
      icon: Sun,
      bg: 'bg-cream-100 text-forest-950 border border-forest-900/10',
      accent: 'border-forest-700/30',
    },
    {
      num: '03',
      title: 'NUTRITIOUS',
      tagline: 'Wholesome mushrooms for everyday meals.',
      desc: 'Packed with natural Vitamin D, essential minerals, plant protein, and immune-supporting antioxidants.',
      icon: HeartPulse,
      bg: 'bg-cream-200 text-forest-950 border border-golden-500/20',
      accent: 'border-golden-500/40',
    },
    {
      num: '04',
      title: 'DELIVERED WITH CARE',
      tagline: 'Packed carefully so freshness reaches your kitchen.',
      desc: 'Enclosed in breathable kraft paper packaging and cold-transported straight to your doorstep.',
      icon: PackageCheck,
      bg: 'bg-forest-950 text-cream-50',
      accent: 'border-golden-500/30',
    },
  ];

  return (
    <section className="py-24 bg-forest-950 text-cream-50 relative overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-1/2 left-0 w-80 h-80 bg-forest-800/30 blur-3xl rounded-full pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-golden-500/10 blur-3xl rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <SectionHeading
          eyebrow="WHY CHOOSE BABA JI"
          title="THE BABA JI FARMS DIFFERENCE"
          subtitle="Four pillars of organic excellence that define our commitment to your health and culinary joy."
          theme="dark"
        />

        {/* ASYMMETRIC ORGANIC BENEFIT CARDS */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8 mt-12">
          {benefits.map((benefit, idx) => {
            const Icon = benefit.icon;
            return (
              <motion.div
                key={benefit.num}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.6, delay: idx * 0.12 }}
                className={`rounded-3xl p-8 flex flex-col justify-between shadow-2xl relative overflow-hidden transition-all duration-300 hover:-translate-y-2 ${benefit.bg} ${
                  idx % 2 === 1 ? 'lg:translate-y-6' : ''
                }`}
              >
                {/* LARGE BACKGROUND NUMBER WATERMARK */}
                <span className="absolute -top-4 -right-2 text-7xl font-serif font-extrabold opacity-10 select-none pointer-events-none">
                  {benefit.num}
                </span>

                <div>
                  <div className="flex items-center justify-between mb-8">
                    <span className="text-xs font-mono tracking-widest uppercase opacity-70 font-semibold">
                      {benefit.num} // PILLAR
                    </span>
                    <div className="p-3 rounded-2xl bg-forest-800/30 border border-golden-500/20">
                      <Icon className="w-6 h-6 text-golden-400" />
                    </div>
                  </div>

                  <h3 className="text-xl font-serif font-bold tracking-wide mb-2">
                    {benefit.title}
                  </h3>
                  <p className="text-xs font-semibold text-golden-400 uppercase tracking-wider mb-4">
                    "{benefit.tagline}"
                  </p>
                  <p className="text-xs sm:text-sm leading-relaxed opacity-80 font-sans">
                    {benefit.desc}
                  </p>
                </div>

                <div className="mt-8 pt-4 border-t border-current/10 flex items-center justify-between text-[11px] uppercase tracking-widest font-mono opacity-60">
                  <span>Baba Ji Promise</span>
                  <span>Pure Organic</span>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
