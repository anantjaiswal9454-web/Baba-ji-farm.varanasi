export type CategoryType = 'ALL' | 'OYSTER' | 'BUTTON' | 'MILKY' | 'SPECIALTY' | 'MIX';

export interface Product {
  id: string;
  name: string;
  slug: string;
  shortDescription: string;
  fullDescription: string;
  price: number; // base price for default weight
  weights: { weight: string; priceMultiplier: number }[];
  defaultWeight: string;
  category: CategoryType;
  image: string;
  gallery: string[];
  rating: number;
  reviewCount: number;
  stock: number;
  isFeatured?: boolean;
  isBestSeller?: boolean;
  isFreshHarvest?: boolean;
  nutrition: {
    calories: string;
    protein: string;
    fiber: string;
    fat: string;
    potassium: string;
    vitaminD: string;
  };
  storageTips: string;
  farmDetails: string;
}

export interface CartItem {
  product: Product;
  selectedWeight: string;
  quantity: number;
  unitPrice: number;
}

export interface Review {
  id: string;
  userName: string;
  location: string;
  rating: number;
  date: string;
  comment: string;
  verifiedBuyer: boolean;
  productName?: string;
  avatar?: string;
}

export interface ProcessStep {
  number: string;
  title: string;
  subtitle: string;
  description: string;
  details: string[];
  image: string;
  iconName: string;
}

export interface Order {
  id: string;
  date: string;
  status: 'Processing' | 'Harvesting Fresh' | 'Out for Delivery' | 'Delivered';
  items: { productName: string; weight: string; quantity: number; price: number }[];
  total: number;
  shippingAddress: string;
}

export interface UserProfile {
  name: string;
  email: string;
  phone: string;
  address: string;
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'info' | 'warning';
  title: string;
  message: string;
}
