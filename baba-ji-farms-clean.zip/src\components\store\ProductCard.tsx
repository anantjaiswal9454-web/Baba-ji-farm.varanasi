import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Heart, ShoppingBag, Star, Eye } from 'lucide-react';
import { Product } from '../../types';
import { useCart } from '../../context/CartContext';
import { useWishlist } from '../../context/WishlistContext';

interface ProductCardProps {
  product: Product;
  onQuickView?: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onQuickView }) => {
  const { addToCart } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();
  const [selectedWeight, setSelectedWeight] = useState(product.defaultWeight);

  const isLiked = isInWishlist(product.id);
  const currentWeightObj = product.weights.find((w) => w.weight === selectedWeight) || product.weights[0];
  const calculatedPrice = Math.round(product.price * currentWeightObj.priceMultiplier);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-40px' }}
      transition={{ duration: 0.5 }}
      className="group bg-cream-50 rounded-3xl border border-cream-200 shadow-organic hover:shadow-organic-lg transition-all duration-300 flex flex-col justify-between overflow-hidden relative"
    >
      {/* BADGES */}
      <div className="absolute top-4 left-4 z-10 flex flex-col gap-1.5 items-start">
        {product.isFreshHarvest && (
          <span className="px-2.5 py-1 rounded-full bg-forest-900 text-golden-400 text-[10px] font-bold uppercase tracking-wider shadow-md border border-golden-500/20">
            Fresh Harvest
          </span>
        )}
        {product.isBestSeller && (
          <span className="px-2.5 py-1 rounded-full bg-golden-500 text-forest-950 text-[10px] font-bold uppercase tracking-wider shadow-md">
            Best Seller
          </span>
        )}
      </div>

      {/* WISHLIST BUTTON */}
      <button
        onClick={() => toggleWishlist(product)}
        className="absolute top-4 right-4 z-10 p-2.5 rounded-full bg-cream-50/90 backdrop-blur-md text-forest-900 hover:text-red-500 shadow-md hover:scale-110 active:scale-95 transition-all"
        aria-label="Add to Wishlist"
      >
        <Heart
          className={`w-4 h-4 transition-colors ${
            isLiked ? 'fill-red-500 text-red-500 animate-pulse' : 'text-forest-900'
          }`}
        />
      </button>

      {/* IMAGE CONTAINER WITH ZOOM */}
      <div className="relative aspect-[4/3] overflow-hidden bg-cream-100 cursor-pointer">
        <Link to={`/product/${product.id}`}>
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out"
          />
        </Link>

        {/* QUICK VIEW OVERLAY */}
        {onQuickView && (
          <button
            onClick={() => onQuickView(product)}
            className="absolute bottom-3 right-3 px-3 py-1.5 rounded-full bg-forest-950/80 hover:bg-forest-950 text-cream-50 text-xs font-semibold flex items-center gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity backdrop-blur-sm"
          >
            <Eye className="w-3.5 h-3.5" />
            Quick View
          </button>
        )}
      </div>

      {/* PRODUCT DETAILS */}
      <div className="p-6 flex-1 flex flex-col justify-between">
        <div>
          {/* CATEGORY & RATING */}
          <div className="flex items-center justify-between text-xs text-earth-700 mb-2 font-mono uppercase tracking-wider">
            <span>{product.category}</span>
            <div className="flex items-center gap-1 text-golden-600 font-semibold">
              <Star className="w-3.5 h-3.5 fill-golden-500 text-golden-500" />
              <span>{product.rating}</span>
              <span className="text-earth-700/60">({product.reviewCount})</span>
            </div>
          </div>

          {/* NAME */}
          <Link to={`/product/${product.id}`}>
            <h3 className="font-serif text-lg font-bold text-forest-950 hover:text-forest-700 transition-colors line-clamp-1">
              {product.name}
            </h3>
          </Link>

          {/* SHORT DESCRIPTION */}
          <p className="text-xs text-earth-800/80 mt-1.5 line-clamp-2 leading-relaxed font-sans">
            {product.shortDescription}
          </p>
        </div>

        {/* WEIGHT SELECTOR & PRICE & ADD TO CART */}
        <div className="mt-6 pt-4 border-t border-cream-200/80">
          {/* WEIGHT PILLS */}
          <div className="flex items-center gap-1.5 mb-4">
            <span className="text-[11px] font-mono text-earth-700 mr-1">Weight:</span>
            {product.weights.map((w) => (
              <button
                key={w.weight}
                onClick={() => setSelectedWeight(w.weight)}
                className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-all ${
                  selectedWeight === w.weight
                    ? 'bg-forest-900 text-cream-50 shadow-sm'
                    : 'bg-cream-200/60 text-earth-800 hover:bg-cream-200'
                }`}
              >
                {w.weight}
              </button>
            ))}
          </div>

          <div className="flex items-center justify-between">
            {/* PRICE */}
            <div>
              <span className="text-xs text-earth-700 font-mono block">Price</span>
              <span className="font-serif text-xl font-bold text-forest-950">
                ₹{calculatedPrice}
              </span>
            </div>

            {/* ADD TO CART BUTTON */}
            <button
              onClick={() => addToCart(product, selectedWeight, 1)}
              className="px-4 py-2.5 rounded-full bg-forest-900 hover:bg-forest-800 text-cream-50 text-xs font-semibold uppercase tracking-wider flex items-center gap-2 shadow-md hover:scale-105 active:scale-95 transition-all"
            >
              <ShoppingBag className="w-3.5 h-3.5 text-golden-400" />
              ADD
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
};
