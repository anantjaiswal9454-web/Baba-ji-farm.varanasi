import React from 'react';
import { Link } from 'react-router-dom';
import { Instagram, Facebook, Youtube, MapPin, Phone, Mail, ArrowUpRight, User } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-forest-950 text-cream-100 pt-20 pb-10 border-t border-forest-800/40 relative overflow-hidden">
      {/* Subtle background glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-48 bg-forest-800/20 blur-3xl rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 pb-16 border-b border-forest-800/50">
          
          {/* BRAND COLUMN */}
          <div className="lg:col-span-2 space-y-6">
            <Link to="/" className="flex items-center gap-3 group">
              <div className="w-14 h-14 rounded-full border-2 border-golden-500/40 overflow-hidden shadow-golden-glow">
                <img src="/assets/logo.jpg" alt="Baba Ji Farms Logo" className="w-full h-full object-cover" />
              </div>
              <div>
                <span className="font-serif text-2xl font-bold text-cream-50 block tracking-tight">
                  BABA JI FARMS
                </span>
                <span className="text-xs text-golden-500 font-mono tracking-widest uppercase">
                  GROWN WITH CARE, DELIVERED WITH LOVE
                </span>
              </div>
            </Link>

            <p className="text-sm text-cream-200/70 leading-relaxed max-w-md">
              Founded by <strong className="text-cream-50">Abhay Jaiswal</strong>, Baba Ji Farms is dedicated to cultivating 100% natural, pesticide-free organic mushrooms in Varanasi, Uttar Pradesh. Harvested fresh every morning for your kitchen.
            </p>

            <div className="flex items-center gap-4 text-cream-200">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-forest-900 border border-forest-800 flex items-center justify-center hover:bg-golden-500 hover:text-forest-950 transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-forest-900 border border-forest-800 flex items-center justify-center hover:bg-golden-500 hover:text-forest-950 transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-forest-900 border border-forest-800 flex items-center justify-center hover:bg-golden-500 hover:text-forest-950 transition-colors"
                aria-label="YouTube"
              >
                <Youtube className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* NAVIGATION LINKS */}
          <div>
            <h4 className="font-serif text-lg font-semibold text-cream-50 mb-6 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-golden-500" />
              EXPLORE
            </h4>
            <ul className="space-y-3 text-sm text-cream-200/80">
              <li>
                <Link to="/" className="hover:text-golden-400 transition-colors flex items-center gap-1 group">
                  <span>Home</span>
                  <ArrowUpRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                </Link>
              </li>
              <li>
                <Link to="/store" className="hover:text-golden-400 transition-colors flex items-center gap-1 group">
                  <span>Fresh Store</span>
                  <ArrowUpRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                </Link>
              </li>
              <li>
                <Link to="/about" className="hover:text-golden-400 transition-colors flex items-center gap-1 group">
                  <span>About Our Farm</span>
                  <ArrowUpRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                </Link>
              </li>
              <li>
                <Link to="/process" className="hover:text-golden-400 transition-colors flex items-center gap-1 group">
                  <span>Farm to Table Process</span>
                  <ArrowUpRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                </Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-golden-400 transition-colors flex items-center gap-1 group">
                  <span>Contact Us</span>
                  <ArrowUpRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                </Link>
              </li>
            </ul>
          </div>

          {/* CUSTOMER LINKS */}
          <div>
            <h4 className="font-serif text-lg font-semibold text-cream-50 mb-6 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-golden-500" />
              CUSTOMER CARE
            </h4>
            <ul className="space-y-3 text-sm text-cream-200/80">
              <li>
                <Link to="/cart" className="hover:text-golden-400 transition-colors">
                  Cart & Checkout
                </Link>
              </li>
              <li>
                <Link to="/wishlist" className="hover:text-golden-400 transition-colors">
                  My Wishlist
                </Link>
              </li>
              <li>
                <Link to="/account" className="hover:text-golden-400 transition-colors">
                  My Orders & Account
                </Link>
              </li>
              <li>
                <a href="#shipping" className="hover:text-golden-400 transition-colors">
                  Shipping & Delivery Info
                </a>
              </li>
              <li>
                <a href="#privacy" className="hover:text-golden-400 transition-colors">
                  Privacy Policy & Terms
                </a>
              </li>
            </ul>
          </div>

          {/* FARM LOCATION & OWNER */}
          <div>
            <h4 className="font-serif text-lg font-semibold text-cream-50 mb-6 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-golden-500" />
              OUR FARM INFO
            </h4>
            <ul className="space-y-3 text-xs text-cream-200/80">
              <li className="flex items-center gap-2">
                <User className="w-4 h-4 text-golden-500 shrink-0" />
                <span><strong className="text-cream-50">Owner:</strong> Abhay Jaiswal</span>
              </li>
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-golden-500 shrink-0 mt-0.5" />
                <span>Baba Ji Organic Mushroom Farm, Varanasi, Uttar Pradesh, India</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-golden-500 shrink-0" />
                <span><strong className="text-cream-50">Mob:</strong> +91 91400 37160</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-golden-500 shrink-0" />
                <span>abhay@babajifarms.com</span>
              </li>
            </ul>
          </div>
        </div>

        {/* COPYRIGHT BOTTOM BAR */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-cream-200/50">
          <p>© 2026 Baba Ji Farms (Varanasi, UP). All rights reserved.</p>
          <div className="flex items-center gap-6">
            <span className="hover:text-cream-100 transition-colors cursor-pointer">Privacy Policy</span>
            <span className="hover:text-cream-100 transition-colors cursor-pointer">Terms of Service</span>
            <span className="hover:text-cream-100 transition-colors cursor-pointer">Certified Organic Farm</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
