import React, { useState } from 'react';
import { User, Package, LogIn, Truck } from 'lucide-react';
import { Order, UserProfile } from '../types';

export const AccountPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'login' | 'orders' | 'profile'>('profile');

  const [mockUser] = useState<UserProfile>({
    name: 'Abhay Jaiswal',
    email: 'abhay@babajifarms.com',
    phone: '+91 91400 37160',
    address: 'Baba Ji Organic Mushroom Farm, Varanasi, Uttar Pradesh - 221001',
  });

  const mockOrders: Order[] = [
    {
      id: 'BJF-ORD-9021',
      date: 'September 2, 2026',
      status: 'Harvesting Fresh',
      items: [
        { productName: 'Fresh Pearl Oyster Mushroom', weight: '500g', quantity: 1, price: 330 },
        { productName: 'Baba Ji Gourmet Farm Selection Box', weight: '750g Box', quantity: 1, price: 450 },
      ],
      total: 780,
      shippingAddress: 'Varanasi, Uttar Pradesh',
    },
  ];

  return (
    <div className="min-h-screen bg-cream-50 text-earth-900 pt-28 pb-24">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="flex items-center gap-4 bg-forest-950 text-cream-50 p-6 rounded-3xl mb-8 border border-golden-500/20 shadow-xl">
          <div className="w-16 h-16 rounded-full bg-forest-900 border-2 border-golden-500 overflow-hidden shrink-0">
            <img src="/assets/logo.jpg" alt="Logo" className="w-full h-full object-cover" />
          </div>
          <div>
            <span className="text-[10px] text-golden-400 font-mono uppercase tracking-widest">
              BABA JI FARMS • FOUNDER & OWNER
            </span>
            <h1 className="font-serif text-2xl sm:text-3xl font-bold">{mockUser.name}</h1>
            <p className="text-xs text-cream-200/70">{mockUser.email} • {mockUser.phone}</p>
          </div>
        </div>

        {/* TABS */}
        <div className="flex items-center gap-2 border-b border-cream-200 pb-4 mb-8">
          <button
            onClick={() => setActiveTab('profile')}
            className={`px-5 py-2.5 rounded-full text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all ${
              activeTab === 'profile' ? 'bg-forest-900 text-golden-400 shadow-md' : 'bg-cream-100 text-earth-800'
            }`}
          >
            <User className="w-4 h-4" /> Owner Profile
          </button>
          <button
            onClick={() => setActiveTab('orders')}
            className={`px-5 py-2.5 rounded-full text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all ${
              activeTab === 'orders' ? 'bg-forest-900 text-golden-400 shadow-md' : 'bg-cream-100 text-earth-800'
            }`}
          >
            <Package className="w-4 h-4" /> Farm Orders ({mockOrders.length})
          </button>
          <button
            onClick={() => setActiveTab('login')}
            className={`px-5 py-2.5 rounded-full text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all ${
              activeTab === 'login' ? 'bg-forest-900 text-golden-400 shadow-md' : 'bg-cream-100 text-earth-800'
            }`}
          >
            <LogIn className="w-4 h-4" /> Switch Account
          </button>
        </div>

        {/* TAB CONTENTS */}
        {activeTab === 'profile' && (
          <div className="bg-cream-100 rounded-3xl p-8 border border-cream-200 shadow-organic max-w-xl space-y-4">
            <h3 className="font-serif text-xl font-bold text-forest-950">FARM OWNER DETAILS</h3>
            <div className="space-y-3 text-xs font-mono">
              <div>
                <span className="text-earth-700 block">Owner / Founder Name</span>
                <span className="font-bold text-sm text-forest-950">{mockUser.name}</span>
              </div>
              <div>
                <span className="text-earth-700 block">Direct Mobile / WhatsApp</span>
                <span className="font-bold text-sm text-golden-600">{mockUser.phone}</span>
              </div>
              <div>
                <span className="text-earth-700 block">Official Email</span>
                <span className="font-bold text-sm text-forest-950">{mockUser.email}</span>
              </div>
              <div>
                <span className="text-earth-700 block">Farm Location</span>
                <span className="font-bold text-sm text-forest-950">{mockUser.address}</span>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'orders' && (
          <div className="space-y-6">
            {mockOrders.map((order) => (
              <div key={order.id} className="bg-cream-100 rounded-3xl p-6 border border-cream-200 shadow-organic space-y-4">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between border-b border-cream-200 pb-3 gap-2">
                  <div>
                    <span className="text-xs font-mono font-bold text-forest-900">{order.id}</span>
                    <span className="text-xs text-earth-700 font-mono block">Ordered on {order.date}</span>
                  </div>
                  <span className="px-3 py-1 rounded-full text-xs font-mono font-bold uppercase flex items-center gap-1.5 bg-golden-500/20 text-golden-700 border border-golden-500/30">
                    <Truck className="w-3.5 h-3.5" /> {order.status}
                  </span>
                </div>

                <div className="space-y-2 text-xs">
                  {order.items.map((item, idx) => (
                    <div key={idx} className="flex justify-between font-mono">
                      <span>{item.quantity}x {item.productName} ({item.weight})</span>
                      <span className="font-bold">₹{item.price}</span>
                    </div>
                  ))}
                </div>

                <div className="pt-3 border-t border-cream-200 flex justify-between items-center text-sm font-serif font-bold">
                  <span>Total Amount Paid</span>
                  <span className="text-lg text-forest-950">₹{order.total}</span>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'login' && (
          <div className="bg-cream-100 rounded-3xl p-8 border border-cream-200 shadow-organic max-w-md mx-auto space-y-6">
            <h3 className="font-serif text-2xl font-bold text-forest-950 text-center">FARM PORTAL LOGIN</h3>
            <p className="text-xs text-earth-700 text-center">Access your Baba Ji Farms dashboard.</p>
            <div className="space-y-4">
              <div>
                <label className="text-xs font-mono text-earth-700 block mb-1">Mobile or Email</label>
                <input type="text" placeholder="+91 91400 37160" className="w-full px-3.5 py-2.5 rounded-xl border border-cream-300 bg-cream-50 text-xs" />
              </div>
              <div>
                <label className="text-xs font-mono text-earth-700 block mb-1">Password</label>
                <input type="password" placeholder="••••••••" className="w-full px-3.5 py-2.5 rounded-xl border border-cream-300 bg-cream-50 text-xs" />
              </div>
              <button className="w-full py-3 rounded-full bg-forest-950 text-cream-50 font-bold text-xs uppercase tracking-widest">
                LOG IN TO BABA JI PORTAL
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
