import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { SectionHeading } from '../common/SectionHeading';
import { ProductCard } from '../store/ProductCard';
import { MOCK_PRODUCTS } from '../../data/products';
import { Product } from '../../types';
import { QuickViewModal } from '../store/QuickViewModal';
import { ArrowRight } from 'lucide-react';

export const FeaturedProducts: React.FC = () => {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const featured = MOCK_PRODUCTS.filter((p) => p.isFeatured).slice(0, 4);

  return (
    <section className="py-24 bg-cream-100/60 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="DAILY MORNING HARVEST"
          title="FRESH FROM OUR FARM"
          subtitle="Discover our selection of farm-fresh mushrooms harvested at dawn and packed with natural goodness."
          theme="light"
        />

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8 mt-12">
          {featured.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onQuickView={(p) => setSelectedProduct(p)}
            />
          ))}
        </div>

        {/* VIEW ALL BUTTON */}
        <div className="mt-16 text-center">
          <Link
            to="/store"
            className="inline-flex items-center gap-3 px-8 py-4 rounded-full bg-forest-950 hover:bg-forest-900 text-cream-50 font-semibold text-xs tracking-widest uppercase shadow-xl hover:scale-105 active:scale-95 transition-all group"
          >
            <span>VIEW ALL MUSHROOMS</span>
            <ArrowRight className="w-4 h-4 text-golden-400 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
      </div>

      {/* QUICK VIEW MODAL */}
      {selectedProduct && (
        <QuickViewModal
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
        />
      )}
    </section>
  );
};
