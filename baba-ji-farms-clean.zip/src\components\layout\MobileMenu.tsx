import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ChevronRight, Phone, Mail, MapPin, User } from 'lucide-react';

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MobileMenu: React.FC<MobileMenuProps> = ({ isOpen, onClose }) => {
  const location = useLocation();

  const navLinks = [
    { name: 'HOME', path: '/', subtitle: 'Welcome to Baba Ji Farms' },
    { name: 'STORE', path: '/store', subtitle: 'Browse Fresh Mushrooms' },
    { name: 'ABOUT FARM', path: '/about', subtitle: 'Our Passion & Heritage' },
    { name: 'OUR PROCESS', path: '/process', subtitle: 'Cultivation to Doorstep' },
    { name: 'CONTACT', path: '/contact', subtitle: 'Get in Touch With Us' },
    { name: 'ACCOUNT', path: '/account', subtitle: 'Orders & Profile' },
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-[100] bg-forest-950/80 backdrop-blur-sm"
          />

          {/* Drawer */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 250 }}
            className="fixed top-0 right-0 bottom-0 w-full max-w-md z-[101] bg-forest-950 text-cream-50 flex flex-col justify-between p-6 overflow-y-auto border-l border-forest-800/40"
          >
            {/* Header */}
            <div>
              <div className="flex items-center justify-between border-b border-forest-800/60 pb-6 mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full border border-golden-500/40 overflow-hidden">
                    <img src="/assets/logo.jpg" alt="Logo" className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <h3 className="font-serif font-bold text-lg text-cream-50">BABA JI FARMS</h3>
                    <p className="text-[10px] text-golden-500 font-mono tracking-widest uppercase">
                      VARANASI, UTTAR PRADESH
                    </p>
                  </div>
                </div>
                <button
                  onClick={onClose}
                  className="p-2 rounded-full hover:bg-forest-900 text-cream-200 transition-colors"
                  aria-label="Close menu"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              {/* Links */}
              <nav className="flex flex-col gap-2">
                {navLinks.map((link, idx) => {
                  const isActive = location.pathname === link.path;
                  return (
                    <motion.div
                      key={link.name}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.05 * idx }}
                    >
                      <Link
                        to={link.path}
                        onClick={onClose}
                        className={`flex items-center justify-between p-3 rounded-xl transition-all ${
                          isActive
                            ? 'bg-forest-900 text-golden-400 border border-golden-500/20'
                            : 'hover:bg-forest-900/50 text-cream-100'
                        }`}
                      >
                        <div>
                          <span className="font-serif text-lg font-semibold block">{link.name}</span>
                          <span className="text-xs text-cream-200/50">{link.subtitle}</span>
                        </div>
                        <ChevronRight className={`w-5 h-5 ${isActive ? 'text-golden-400' : 'text-forest-700'}`} />
                      </Link>
                    </motion.div>
                  );
                })}
              </nav>
            </div>

            {/* Footer / Contact info */}
            <div className="pt-6 border-t border-forest-800/60 mt-8 space-y-3 text-xs text-cream-200/70">
              <div className="flex items-center gap-2">
                <User className="w-4 h-4 text-golden-500 shrink-0" />
                <span>Owner: <strong className="text-cream-50">Abhay Jaiswal</strong></span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-golden-500 shrink-0" />
                <span>Baba Ji Organic Mushroom Farm, Varanasi, Uttar Pradesh</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-golden-500 shrink-0" />
                <span>+91 91400 37160</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-golden-500 shrink-0" />
                <span>abhay@babajifarms.com</span>
              </div>
              <p className="text-[10px] text-center text-golden-500/60 pt-4 font-mono tracking-widest uppercase">
                "FRESH • NATURAL • NUTRITIOUS"
              </p>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
