import { Review } from '../types';

export const MOCK_REVIEWS: Review[] = [
  {
    id: 'rev-01',
    userName: 'Rajesh Sharma',
    location: 'Varanasi, UP',
    rating: 5,
    date: 'August 28, 2026',
    comment: 'The freshness of the Oyster mushrooms from Abhay Jaiswal’s Baba Ji Farms is unmatched. Arrived cold-packed, clean, and plump straight from the Varanasi farm!',
    verifiedBuyer: true,
    productName: 'Fresh Pearl Oyster Mushroom',
  },
  {
    id: 'rev-02',
    userName: 'Priya Verma',
    location: 'Lucknow, UP',
    rating: 5,
    date: 'August 24, 2026',
    comment: 'Ordered the Gourmet Selection Box for a family weekend dinner in Lucknow. Beautiful packaging with jute string and rustic tags. Every variety was bursting with natural flavor!',
    verifiedBuyer: true,
    productName: 'Baba Ji Gourmet Farm Selection Box',
  },
  {
    id: 'rev-03',
    userName: 'Dr. Gurpreet Singh',
    location: 'Prayagraj (Allahabad), UP',
    rating: 5,
    date: 'August 19, 2026',
    comment: 'As a nutritionist, I love that Mr. Abhay Jaiswal uses zero chemical sprays. The Summer Milky mushrooms have incredible stem thickness and last over a week in the fridge.',
    verifiedBuyer: true,
    productName: 'Organic Summer Milky Mushroom',
  },
  {
    id: 'rev-04',
    userName: 'Ananya Malhotra',
    location: 'Varanasi Cantt, UP',
    rating: 5,
    date: 'August 15, 2026',
    comment: 'Subscribed to weekly delivery in Varanasi! Always delivered right on time by Abhay Jaiswal’s farm team, harvest-fresh with morning dew still on the caps. 10/10 recommendation.',
    verifiedBuyer: true,
    productName: 'Farm Fresh White Button Mushroom',
  }
];
