import React, { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Star, Heart, ShoppingBag, ArrowLeft, ShieldCheck, Truck, RefreshCw, CheckCircle2, Info } from 'lucide-react';
import { MOCK_PRODUCTS } from '../data/products';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { ProductCard } from '../components/store/ProductCard';

export const ProductDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { addToCart, setIsCartOpen } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();

  const product = MOCK_PRODUCTS.find((p) => p.id === id || p.slug === id) || MOCK_PRODUCTS[0];

  const [activeImage, setActiveImage] = useState(product.image);
  const [selectedWeight, setSelectedWeight] = useState(product.defaultWeight);
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<'description' | 'nutrition' | 'storage' | 'farm'>('description');

  const isLiked = isInWishlist(product.id);
  const currentWeightObj = product.weights.find((w) => w.weight === selectedWeight) || product.weights[0];
  const unitPrice = Math.round(product.price * currentWeightObj.priceMultiplier);
  const totalPrice = unitPrice * quantity;

  const relatedProducts = MOCK_PRODUCTS.filter((p) => p.id !== product.id).slice(0, 4);

  return (
    <div className="min-h-screen bg-cream-50 text-earth-900 pt-28 pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* BREADCRUMB */}
        <div className="flex items-center gap-2 text-xs font-mono text-earth-700 mb-8">
          <Link to="/store" className="hover:text-forest-900 flex items-center gap-1">
            <ArrowLeft className="w-3.5 h-3.5" /> Back to Store
          </Link>
          <span>/</span>
          <span className="text-earth-900 font-semibold">{product.category}</span>
          <span>/</span>
          <span className="text-forest-900 font-bold truncate max-w-xs">{product.name}</span>
        </div>

        {/* MAIN PRODUCT GRID */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 mb-16">
          
          {/* GALLERY COLUMN */}
          <div className="lg:col-span-7 space-y-4">
            {/* MAIN IMAGE */}
            <div className="relative aspect-[4/3] sm:aspect-square rounded-3xl overflow-hidden bg-cream-100 border border-cream-200 shadow-organic">
              <img
                src={activeImage || product.image}
                alt={product.name}
                className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
              />
              <button
                onClick={() => toggleWishlist(product)}
                className="absolute top-4 right-4 p-3 rounded-full bg-cream-50/90 backdrop-blur-md text-forest-950 hover:text-red-500 shadow-md transition-transform active:scale-95"
              >
                <Heart className={`w-5 h-5 ${isLiked ? 'fill-red-500 text-red-500' : ''}`} />
              </button>
            </div>

            {/* THUMBNAILS */}
            <div className="flex items-center gap-3 overflow-x-auto no-scrollbar pb-2">
              {product.gallery.map((imgUrl, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveImage(imgUrl)}
                  className={`w-20 h-20 rounded-2xl overflow-hidden border-2 transition-all shrink-0 ${
                    activeImage === imgUrl ? 'border-forest-900 scale-105 shadow-md' : 'border-cream-300 opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={imgUrl} alt="Thumbnail" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </div>

          {/* PURCHASE PANEL */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
            <div>
              <div className="flex items-center justify-between text-xs text-earth-700 font-mono uppercase mb-2">
                <span className="px-2.5 py-1 rounded-full bg-forest-100 text-forest-900 font-bold">
                  {product.category}
                </span>
                <div className="flex items-center gap-1 text-golden-600 font-semibold">
                  <Star className="w-4 h-4 fill-golden-500 text-golden-500" />
                  <span>{product.rating}</span>
                  <span className="text-earth-700/60">({product.reviewCount} Reviews)</span>
                </div>
              </div>

              <h1 className="font-serif text-3xl sm:text-4xl font-bold text-forest-950 leading-tight">
                {product.name}
              </h1>

              <p className="text-sm text-earth-800/80 mt-3 leading-relaxed font-sans">
                {product.fullDescription}
              </p>

              {/* PRICE */}
              <div className="mt-6 flex items-baseline gap-3">
                <span className="font-serif text-4xl font-bold text-forest-950">₹{totalPrice}</span>
                <span className="text-xs text-earth-700 font-mono">
                  (₹{unitPrice} per {selectedWeight})
                </span>
              </div>

              {/* WEIGHT SELECTOR */}
              <div className="mt-6">
                <label className="text-xs font-mono uppercase font-bold text-earth-800 block mb-2">
                  Select Packaging Weight:
                </label>
                <div className="flex flex-wrap gap-2">
                  {product.weights.map((w) => (
                    <button
                      key={w.weight}
                      onClick={() => setSelectedWeight(w.weight)}
                      className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                        selectedWeight === w.weight
                          ? 'bg-forest-900 text-cream-50 shadow-md border border-golden-500/30'
                          : 'bg-cream-200/70 text-earth-900 hover:bg-cream-200 border border-cream-300'
                      }`}
                    >
                      {w.weight}
                    </button>
                  ))}
                </div>
              </div>

              {/* QUANTITY CONTROLLER */}
              <div className="mt-6 flex items-center justify-between">
                <span className="text-xs font-mono uppercase font-bold text-earth-800">Quantity:</span>
                <div className="flex items-center border border-cream-300 rounded-full bg-cream-100 overflow-hidden">
                  <button
                    onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                    className="px-4 py-1.5 text-base font-bold text-forest-950 hover:bg-cream-200"
                  >
                    -
                  </button>
                  <span className="px-6 text-sm font-bold font-mono text-forest-950">{quantity}</span>
                  <button
                    onClick={() => setQuantity((q) => q + 1)}
                    className="px-4 py-1.5 text-base font-bold text-forest-950 hover:bg-cream-200"
                  >
                    +
                  </button>
                </div>
              </div>
            </div>

            {/* ACTION BUTTONS */}
            <div className="space-y-3 pt-6 border-t border-cream-200">
              <button
                onClick={() => addToCart(product, selectedWeight, quantity)}
                className="w-full py-4 rounded-full bg-forest-950 hover:bg-forest-900 text-cream-50 font-bold text-xs uppercase tracking-widest flex items-center justify-center gap-2 shadow-xl hover:scale-[1.02] active:scale-98 transition-all"
              >
                <ShoppingBag className="w-4 h-4 text-golden-400" />
                ADD TO BASKET • ₹{totalPrice}
              </button>

              <button
                onClick={() => {
                  addToCart(product, selectedWeight, quantity);
                  setIsCartOpen(true);
                }}
                className="w-full py-4 rounded-full bg-golden-500 hover:bg-golden-400 text-forest-950 font-bold text-xs uppercase tracking-widest shadow-golden-glow hover:scale-[1.02] active:scale-98 transition-all"
              >
                BUY NOW
              </button>

              <div className="grid grid-cols-2 gap-3 pt-4 text-[11px] text-earth-800 font-mono">
                <div className="flex items-center gap-2">
                  <Truck className="w-4 h-4 text-forest-700" />
                  <span>Harvested Morning Dispatch</span>
                </div>
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-forest-700" />
                  <span>100% Organic Pesticide Free</span>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* DETAILED TABS SECTION */}
        <div className="bg-cream-100/70 rounded-3xl p-8 border border-cream-200 shadow-organic mb-20">
          <div className="flex items-center gap-4 border-b border-cream-200 pb-4 overflow-x-auto no-scrollbar">
            {(['description', 'nutrition', 'storage', 'farm'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-5 py-2.5 rounded-full text-xs font-bold uppercase tracking-wider transition-all ${
                  activeTab === tab
                    ? 'bg-forest-900 text-golden-400 shadow-md'
                    : 'bg-cream-50 text-earth-800 hover:bg-cream-200'
                }`}
              >
                {tab === 'description' && "Why You'll Love It"}
                {tab === 'nutrition' && 'Nutritional Facts'}
                {tab === 'storage' && 'Storage Tips'}
                {tab === 'farm' && 'Farm Cultivation Info'}
              </button>
            ))}
          </div>

          <div className="pt-6 font-sans text-sm text-earth-800 leading-relaxed max-w-4xl">
            {activeTab === 'description' && (
              <div className="space-y-4">
                <h3 className="font-serif text-xl font-bold text-forest-950">Culinary Excellence</h3>
                <p>{product.fullDescription}</p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4">
                  <div className="p-4 bg-cream-50 rounded-2xl border border-cream-200">
                    <span className="font-bold text-forest-900 block mb-1">Ideal Cooking</span>
                    <span>Sauté with garlic, herbs, or incorporate into Indian gravies.</span>
                  </div>
                  <div className="p-4 bg-cream-50 rounded-2xl border border-cream-200">
                    <span className="font-bold text-forest-900 block mb-1">Texture</span>
                    <span>Tender fan-like caps with firm juicy stems.</span>
                  </div>
                  <div className="p-4 bg-cream-50 rounded-2xl border border-cream-200">
                    <span className="font-bold text-forest-900 block mb-1">Flavor Notes</span>
                    <span>Rich umami with delicate natural sweetness.</span>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'nutrition' && (
              <div className="space-y-4">
                <h3 className="font-serif text-xl font-bold text-forest-950">Nutritional Profile (Per 100g)</h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 font-mono text-xs">
                  <div className="p-3 bg-cream-50 rounded-xl border border-cream-200">
                    <span className="text-earth-700 block">Calories</span>
                    <span className="font-bold text-forest-950 text-sm">{product.nutrition.calories}</span>
                  </div>
                  <div className="p-3 bg-cream-50 rounded-xl border border-cream-200">
                    <span className="text-earth-700 block">Plant Protein</span>
                    <span className="font-bold text-forest-950 text-sm">{product.nutrition.protein}</span>
                  </div>
                  <div className="p-3 bg-cream-50 rounded-xl border border-cream-200">
                    <span className="text-earth-700 block">Dietary Fiber</span>
                    <span className="font-bold text-forest-950 text-sm">{product.nutrition.fiber}</span>
                  </div>
                  <div className="p-3 bg-cream-50 rounded-xl border border-cream-200">
                    <span className="text-earth-700 block">Potassium</span>
                    <span className="font-bold text-forest-950 text-sm">{product.nutrition.potassium}</span>
                  </div>
                  <div className="p-3 bg-cream-50 rounded-xl border border-cream-200">
                    <span className="text-earth-700 block">Vitamin D</span>
                    <span className="font-bold text-forest-950 text-sm">{product.nutrition.vitaminD}</span>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'storage' && (
              <div className="space-y-4">
                <h3 className="font-serif text-xl font-bold text-forest-950">Freshness Storage Guide</h3>
                <p className="bg-cream-50 p-4 rounded-2xl border border-cream-200 font-mono text-xs">
                  {product.storageTips}
                </p>
              </div>
            )}

            {activeTab === 'farm' && (
              <div className="space-y-4">
                <h3 className="font-serif text-xl font-bold text-forest-950">Cultivation & Harvest Notes</h3>
                <p className="bg-cream-50 p-4 rounded-2xl border border-cream-200 font-mono text-xs">
                  {product.farmDetails}
                </p>
              </div>
            )}
          </div>
        </div>

        {/* RELATED PRODUCTS */}
        <div>
          <h3 className="font-serif text-2xl font-bold text-forest-950 mb-6">YOU MAY ALSO LIKE</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {relatedProducts.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
