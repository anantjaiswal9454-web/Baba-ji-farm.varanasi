import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Heart, Compass, CheckCircle2, User, MapPin } from 'lucide-react';

export const FarmStorySection: React.FC = () => {
  return (
    <section className="py-24 bg-cream-50 text-earth-900 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* LEFT: LARGE FARM PHOTOGRAPHY WITH MASCOT EMBLEM */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8 }}
            className="lg:col-span-6 relative"
          >
            <div className="relative rounded-3xl overflow-hidden shadow-2xl border-4 border-cream-200 aspect-[4/3] sm:aspect-[16/10]">
              <img
                src="/assets/hero.jpg"
                alt="Baba Ji Organic Farm Cultivation"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-forest-950/80 via-transparent to-transparent" />

              {/* FLOATING MASCOT BADGE */}
              <div className="absolute top-6 left-6 flex items-center gap-3 p-3 bg-forest-950/90 backdrop-blur-md rounded-full border border-golden-500/30 text-cream-50 shadow-xl">
                <div className="w-12 h-12 rounded-full overflow-hidden border border-golden-500">
                  <img src="/assets/logo.jpg" alt="Logo" className="w-full h-full object-cover" />
                </div>
                <div className="pr-3">
                  <span className="font-serif font-bold text-xs block text-cream-50">ABHAY JAISWAL</span>
                  <span className="text-[10px] text-golden-400 font-mono">VARANASI, UTTAR PRADESH</span>
                </div>
              </div>

              <div className="absolute bottom-6 left-6 right-6 p-6 bg-forest-900/95 backdrop-blur-md rounded-2xl border border-golden-500/30 text-cream-50">
                <p className="font-serif text-sm italic text-cream-100">
                  "Farming is not just our business — it is our sacred responsibility to bring pure food to every household."
                </p>
                <span className="text-xs text-golden-400 font-mono tracking-widest uppercase mt-2 block font-semibold">
                  — Abhay Jaiswal (Founder & Master Grower)
                </span>
              </div>
            </div>
          </motion.div>

          {/* RIGHT: STORY TEXT */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8 }}
            className="lg:col-span-6 space-y-6"
          >
            <span className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-forest-100 text-forest-900 text-xs font-semibold uppercase tracking-widest border border-forest-500/20">
              <Heart className="w-3.5 h-3.5 text-forest-700" />
              FOUNDER'S VISION
            </span>

            <h2 className="text-3xl sm:text-5xl font-serif font-bold text-forest-950 leading-tight">
              THE STORY BEHIND BABA JI FARMS
            </h2>

            <p className="text-base text-earth-800/90 leading-relaxed font-sans">
              Founded by <strong className="text-forest-950">Abhay Jaiswal</strong> in Varanasi, Uttar Pradesh, Baba Ji Farms began with a mission to revolutionize mushroom cultivation in northern India by providing 100% pesticide-free organic mushrooms.
            </p>

            <p className="text-base text-earth-800/90 leading-relaxed font-sans">
              Nestled along the fertile agricultural belt of Varanasi, our state-of-the-art mushroom farm blends traditional organic substrate preparation with advanced climate-controlled misting chambers. Under Abhay Jaiswal's personal oversight, every harvest guarantees unmatched freshness.
            </p>

            <div className="space-y-3 pt-2">
              <div className="flex items-center gap-3 text-sm font-semibold text-forest-900">
                <CheckCircle2 className="w-5 h-5 text-forest-700 shrink-0" />
                <span>Personally Founded & Managed by Abhay Jaiswal</span>
              </div>
              <div className="flex items-center gap-3 text-sm font-semibold text-forest-900">
                <CheckCircle2 className="w-5 h-5 text-forest-700 shrink-0" />
                <span>Located in Varanasi, Uttar Pradesh (Mob: +91 91400 37160)</span>
              </div>
              <div className="flex items-center gap-3 text-sm font-semibold text-forest-900">
                <CheckCircle2 className="w-5 h-5 text-forest-700 shrink-0" />
                <span>Daily Morning Harvest & Express Dispatch</span>
              </div>
            </div>

            <div className="pt-4">
              <Link
                to="/about"
                className="inline-flex items-center gap-3 px-8 py-4 rounded-full bg-forest-900 hover:bg-forest-800 text-cream-50 text-xs font-semibold tracking-widest uppercase shadow-xl hover:scale-105 active:scale-95 transition-all group"
              >
                <Compass className="w-4 h-4 text-golden-400 group-hover:rotate-45 transition-transform" />
                <span>LEARN MORE ABOUT OUR FARM</span>
              </Link>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
};
