import { ProcessStep } from '../types';

export const PROCESS_STEPS: ProcessStep[] = [
  {
    number: '01',
    title: 'ORGANIC SUBSTRATE PREPARATION',
    subtitle: 'Pure Wheat Straw & Mineral Casing',
    description: 'We blend organic wheat straw and natural mineral casing, steam-sterilizing it at 121°C to ensure a pathogen-free, nutrient-rich foundation.',
    details: [
      '100% natural organic compost substrate',
      'High-pressure steam sterilization',
      'Strictly zero synthetic chemicals or additives',
    ],
    image: '/assets/hero.jpg',
    iconName: 'Sprout',
  },
  {
    number: '02',
    title: 'PRECISION CLIMATE GROWING',
    subtitle: 'Automated Mist & Oxygen Flow',
    description: 'Our mushrooms flourish inside climate-controlled rooms maintaining 88% humidity and gentle mountain air circulation 24 hours a day.',
    details: [
      'Ultrasound cold mist technology',
      'HEPA filtered fresh air exchanges',
      'Constant 18°C - 22°C ambient monitoring',
    ],
    image: '/assets/oyster.jpg',
    iconName: 'Wind',
  },
  {
    number: '03',
    title: 'HAND HARVESTING AT DAWN',
    subtitle: 'Picked at Peak Nutritional Maturity',
    description: 'Master growers inspect every cluster and gently hand-pick mushrooms at dawn when water retention and cap density are highest.',
    details: [
      'Individual cluster inspection',
      'Gently twisted to preserve mycelium beds',
      'Harvested twice daily for maximum freshness',
    ],
    image: '/assets/button.jpg',
    iconName: 'Hand',
  },
  {
    number: '04',
    title: 'ECO-FRIENDLY COLD PACKAGING',
    subtitle: 'Ventilated Kraft & Breathable Seals',
    description: 'Mushrooms are immediately sorted in our 4°C packing bay into breathable kraft boxes and biodegradable punnets.',
    details: [
      'Insulated eco-friendly paper packaging',
      'Prevents moisture pooling and sogginess',
      'Includes batch harvest date label',
    ],
    image: '/assets/mix.jpg',
    iconName: 'BoxCheck',
  },
  {
    number: '05',
    title: 'EXPRESS DOORSTEP DELIVERY',
    subtitle: 'Farm to Kitchen within 12 Hours',
    description: 'Dispatched via temperature-controlled delivery partners so your mushrooms arrive crisp, fragrant, and ready for your gourmet recipes.',
    details: [
      'Same-day harvest & dispatch',
      'Real-time delivery status tracking',
      'Guaranteed farm-fresh quality upon arrival',
    ],
    image: '/assets/milky.jpg',
    iconName: 'Truck',
  },
];
