import React, { useState, useMemo } from 'react';
import { SectionHeading } from '../components/common/SectionHeading';
import { ProductFilterBar } from '../components/store/ProductFilterBar';
import { ProductCard } from '../components/store/ProductCard';
import { MOCK_PRODUCTS } from '../data/products';
import { CategoryType, Product } from '../types';
import { QuickViewModal } from '../components/store/QuickViewModal';
import { SporeParticles } from '../components/common/SporeParticles';

export const StorePage: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<CategoryType>('ALL');
  const [sortBy, setSortBy] = useState('featured');
  const [maxPrice, setMaxPrice] = useState(500);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const filteredProducts = useMemo(() => {
    return MOCK_PRODUCTS.filter((product) => {
      // Category filter
      if (selectedCategory !== 'ALL' && product.category !== selectedCategory) return false;
      // Search query filter
      if (
        searchQuery &&
        !product.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
        !product.shortDescription.toLowerCase().includes(searchQuery.toLowerCase())
      ) {
        return false;
      }
      // Price filter
      if (product.price > maxPrice) return false;
      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-low') return a.price - b.price;
      if (sortBy === 'price-high') return b.price - a.price;
      if (sortBy === 'rating') return b.rating - a.rating;
      return (b.isFeatured ? 1 : 0) - (a.isFeatured ? 1 : 0);
    });
  }, [searchQuery, selectedCategory, sortBy, maxPrice]);

  return (
    <div className="min-h-screen bg-cream-50 text-earth-900 pt-28 pb-24">
      {/* STORE HEADER HERO BANNER */}
      <div className="relative bg-forest-950 text-cream-50 py-16 mb-12 overflow-hidden border-b border-golden-500/20">
        <SporeParticles density={25} speed={1} />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <span className="text-xs font-mono font-bold tracking-widest text-golden-400 uppercase">
            BABA JI FARMS ONLINE MARKETPLACE
          </span>
          <h1 className="font-serif text-4xl sm:text-6xl font-bold tracking-tight text-cream-50 mt-2">
            FRESH FROM THE FARM
          </h1>
          <p className="text-sm sm:text-base text-cream-200/80 max-w-xl mx-auto mt-3 font-sans">
            Hand-harvested daily at dawn. Browse our certified organic Pearl Oyster, White Button, Summer Milky, and Gourmet Mixes.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* FILTER BAR */}
        <ProductFilterBar
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          selectedCategory={selectedCategory}
          setSelectedCategory={setSelectedCategory}
          sortBy={sortBy}
          setSortBy={setSortBy}
          maxPrice={maxPrice}
          setMaxPrice={setMaxPrice}
          viewMode={viewMode}
          setViewMode={setViewMode}
        />

        {/* RESULTS METRICS */}
        <div className="flex items-center justify-between text-xs text-earth-700 font-mono mb-6">
          <span>Showing {filteredProducts.length} farm fresh products</span>
          {(searchQuery || selectedCategory !== 'ALL' || maxPrice < 500) && (
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('ALL');
                setMaxPrice(500);
              }}
              className="text-forest-900 font-bold hover:underline"
            >
              Reset Filters
            </button>
          )}
        </div>

        {/* PRODUCT GRID / LIST */}
        {filteredProducts.length === 0 ? (
          <div className="py-20 text-center bg-cream-100/50 rounded-3xl border border-cream-200">
            <h3 className="font-serif text-2xl font-bold text-forest-950">No mushrooms found</h3>
            <p className="text-sm text-earth-700 mt-2">Try adjusting your search query or price slider.</p>
          </div>
        ) : (
          <div
            className={
              viewMode === 'grid'
                ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8'
                : 'space-y-6'
            }
          >
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onQuickView={(p) => setSelectedProduct(p)}
              />
            ))}
          </div>
        )}
      </div>

      {/* QUICK VIEW MODAL */}
      {selectedProduct && (
        <QuickViewModal
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
        />
      )}
    </div>
  );
};
