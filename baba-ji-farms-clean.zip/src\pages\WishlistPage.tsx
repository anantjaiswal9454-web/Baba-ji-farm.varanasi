import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Heart, ShoppingBag, Trash2, ArrowRight } from 'lucide-react';
import { useWishlist } from '../context/WishlistContext';
import { useCart } from '../context/CartContext';

export const WishlistPage: React.FC = () => {
  const { wishlist, toggleWishlist } = useWishlist();
  const { addToCart } = useCart();

  return (
    <div className="min-h-screen bg-cream-50 text-earth-900 pt-28 pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-mono font-bold tracking-widest text-golden-600 uppercase">
            SAVED FAVORITES
          </span>
          <h1 className="font-serif text-4xl sm:text-5xl font-bold text-forest-950 mt-2">
            YOUR WISHLIST
          </h1>
        </div>

        {wishlist.length === 0 ? (
          <div className="py-20 text-center bg-cream-100/70 rounded-3xl border border-cream-200 max-w-xl mx-auto p-8 space-y-6">
            <div className="w-20 h-20 mx-auto rounded-full bg-cream-200 flex items-center justify-center text-forest-900">
              <Heart className="w-10 h-10" />
            </div>
            <h3 className="font-serif text-2xl font-bold text-forest-950">
              YOUR FARM-FRESH FAVORITES ARE WAITING.
            </h3>
            <p className="text-xs sm:text-sm text-earth-800/80">
              Save your preferred Pearl Oyster, White Button, or Gourmet Mixes to easily reorder.
            </p>
            <Link
              to="/store"
              className="inline-flex items-center gap-2 px-8 py-4 rounded-full bg-forest-950 text-cream-50 font-bold text-xs uppercase tracking-widest hover:bg-forest-900 transition-all shadow-xl"
            >
              <span>EXPLORE MUSHROOMS</span>
              <ArrowRight className="w-4 h-4 text-golden-400" />
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {wishlist.map((product) => (
              <div
                key={product.id}
                className="bg-cream-100 rounded-3xl border border-cream-200 overflow-hidden p-4 flex flex-col justify-between shadow-organic"
              >
                <div>
                  <div className="aspect-[4/3] rounded-2xl overflow-hidden mb-4 relative">
                    <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
                    <button
                      onClick={() => toggleWishlist(product)}
                      className="absolute top-3 right-3 p-2 rounded-full bg-cream-50/90 text-red-500 hover:scale-110 transition-transform"
                      title="Remove"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  <h3 className="font-serif font-bold text-lg text-forest-950">{product.name}</h3>
                  <p className="text-xs text-earth-700 font-mono mt-1">₹{product.price} / {product.defaultWeight}</p>
                </div>

                <button
                  onClick={() => {
                    addToCart(product);
                    toggleWishlist(product);
                  }}
                  className="mt-6 w-full py-3 rounded-full bg-forest-900 hover:bg-forest-800 text-cream-50 text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2 transition-all"
                >
                  <ShoppingBag className="w-4 h-4 text-golden-400" />
                  MOVE TO BASKET
                </button>
              </div>
            ))}
          </div>
        )}

      </div>
    </div>
  );
};
