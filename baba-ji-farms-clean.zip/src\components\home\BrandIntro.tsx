import React from 'react';
import { motion } from 'framer-motion';
import { Leaf, Award, ShieldCheck, HeartHandshake } from 'lucide-react';

export const BrandIntro: React.FC = () => {
  return (
    <section className="py-24 bg-cream-50 text-earth-900 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* LARGE EDITORIAL TYPOGRAPHY */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8 }}
            className="lg:col-span-7 space-y-6"
          >
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-forest-100 text-forest-900 text-xs font-semibold uppercase tracking-widest border border-forest-500/20">
              <Leaf className="w-3.5 h-3.5 text-forest-700" />
              OUR PHILOSOPHY
            </div>

            <h2 className="text-3xl sm:text-5xl lg:text-6xl font-serif font-bold text-forest-950 leading-[1.12]">
              MORE THAN MUSHROOMS.{' '}
              <span className="italic font-normal text-forest-700 block mt-2">
                IT'S FARM-TO-TABLE CARE.
              </span>
            </h2>

            <p className="text-base sm:text-lg text-earth-800/90 leading-relaxed font-sans max-w-2xl">
              Baba Ji Farms is dedicated to growing fresh, highly nutritious mushrooms with meticulous cultivation techniques and responsible, eco-aligned farming practices. We believe food should nourish both body and spirit.
            </p>

            <div className="grid grid-cols-2 gap-6 pt-4 border-t border-cream-200">
              <div className="space-y-1">
                <span className="font-serif text-3xl font-bold text-forest-900 block">100%</span>
                <span className="text-xs uppercase tracking-wider font-semibold text-earth-700">Pesticide Free</span>
              </div>
              <div className="space-y-1">
                <span className="font-serif text-3xl font-bold text-forest-900 block">Daily</span>
                <span className="text-xs uppercase tracking-wider font-semibold text-earth-700">Dawn Harvest</span>
              </div>
            </div>
          </motion.div>

          {/* LARGE PHOTO OVERLAY WITH PARALLAX FRAME */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.9 }}
            className="lg:col-span-5 relative"
          >
            <div className="relative rounded-3xl overflow-hidden shadow-2xl border-4 border-cream-200 aspect-[4/5]">
              <img
                src="/assets/oyster.jpg"
                alt="Fresh Harvest Oyster Mushrooms"
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-forest-950/80 via-transparent to-transparent" />
              
              <div className="absolute bottom-6 left-6 right-6 p-6 bg-forest-950/90 backdrop-blur-md rounded-2xl border border-golden-500/30 text-cream-50">
                <p className="font-serif italic text-sm text-cream-100">
                  "Every cluster is hand-picked at dawn to preserve natural moisture and umami."
                </p>
                <div className="mt-3 flex items-center justify-between text-xs text-golden-400 font-mono uppercase tracking-wider">
                  <span>Baba Ji Farms Quality Standard</span>
                  <ShieldCheck className="w-4 h-4" />
                </div>
              </div>
            </div>
          </motion.div>
        </div>

      </div>
    </section>
  );
};
