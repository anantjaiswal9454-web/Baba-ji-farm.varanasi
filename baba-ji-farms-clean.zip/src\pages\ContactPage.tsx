import React, { useState } from 'react';
import { Mail, Phone, MapPin, Clock, Send, CheckCircle2, User } from 'lucide-react';
import { useToast } from '../context/ToastContext';

export const ContactPage: React.FC = () => {
  const { addToast } = useToast();
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    addToast('Message Sent!', 'Thank you for reaching out to Abhay Jaiswal at Baba Ji Farms. We will respond within 24 hours.', 'success');
  };

  return (
    <div className="min-h-screen bg-cream-50 text-earth-900 pt-28 pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-xs font-mono font-bold tracking-widest text-golden-600 uppercase">
            WE WOULD LOVE TO HEAR FROM YOU
          </span>
          <h1 className="font-serif text-4xl sm:text-5xl font-bold text-forest-950 mt-2">
            CONTACT BABA JI FARMS
          </h1>
          <p className="text-sm text-earth-800/80 mt-3 font-sans">
            Connect directly with founder <strong className="text-forest-950">Abhay Jaiswal</strong> and our Varanasi mushroom farm team for fresh orders, bulk supply, or queries.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 mb-20">
          
          {/* CONTACT INFO & CARDS */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-forest-950 text-cream-50 rounded-3xl p-8 space-y-6 shadow-2xl border border-golden-500/20">
              <div className="flex items-center gap-3 border-b border-forest-800 pb-4">
                <div className="w-12 h-12 rounded-full border border-golden-500 overflow-hidden">
                  <img src="/assets/logo.jpg" alt="Logo" className="w-full h-full object-cover" />
                </div>
                <div>
                  <h3 className="font-serif font-bold text-lg text-cream-50">BABA JI FARMS</h3>
                  <p className="text-[10px] text-golden-400 font-mono uppercase">Varanasi, Uttar Pradesh</p>
                </div>
              </div>

              <div className="space-y-4 text-xs">
                <div className="flex items-start gap-3">
                  <User className="w-5 h-5 text-golden-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-cream-100 block">Owner / Master Grower</span>
                    <span className="text-cream-200/90 font-semibold text-sm">Abhay Jaiswal</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-golden-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-cream-100 block">Farm & Facility Location</span>
                    <span className="text-cream-200/80">Baba Ji Organic Mushroom Farm, Varanasi, Uttar Pradesh - 221001</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Phone className="w-5 h-5 text-golden-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-cream-100 block">Direct Mobile / WhatsApp</span>
                    <span className="text-golden-400 font-mono text-sm font-bold">+91 91400 37160</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Mail className="w-5 h-5 text-golden-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-cream-100 block">Email Inquiries</span>
                    <span className="text-cream-200/70">abhay@babajifarms.com</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Clock className="w-5 h-5 text-golden-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-cream-100 block">Operating Hours</span>
                    <span className="text-cream-200/70">Monday - Saturday: 6:00 AM - 7:00 PM (Daily Dawn Harvest)</span>
                  </div>
                </div>
              </div>
            </div>

            {/* LOCATION CARD */}
            <div className="bg-cream-100 rounded-3xl p-6 border border-cream-200 text-center space-y-2">
              <MapPin className="w-8 h-8 text-forest-900 mx-auto" />
              <h4 className="font-serif font-bold text-base text-forest-950">VARANASI FARM FACILITY</h4>
              <p className="text-xs text-earth-700">Located in Varanasi, UP. Morning fresh harvest pickup available by appointment.</p>
            </div>
          </div>

          {/* CONTACT FORM */}
          <div className="lg:col-span-7 bg-cream-100 rounded-3xl p-8 sm:p-10 border border-cream-200 shadow-organic">
            {submitted ? (
              <div className="py-16 text-center space-y-4">
                <CheckCircle2 className="w-16 h-16 text-forest-900 mx-auto" />
                <h3 className="font-serif text-2xl font-bold text-forest-950">MESSAGE RECEIVED!</h3>
                <p className="text-xs text-earth-800 max-w-md mx-auto">
                  Thank you for writing to Abhay Jaiswal. We will get back to your phone or email within 24 hours.
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="px-6 py-2.5 rounded-full bg-forest-950 text-cream-50 text-xs font-bold uppercase"
                >
                  Send Another Message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <h3 className="font-serif text-2xl font-bold text-forest-950 border-b border-cream-200 pb-4">
                  DIRECT MESSAGE TO ABHAY JAISWAL
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-mono text-earth-700 block mb-1">Your Name</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Ramesh Kumar"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-cream-300 bg-cream-50 text-sm focus:outline-none focus:border-forest-900"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-mono text-earth-700 block mb-1">Email Address</label>
                    <input
                      type="email"
                      required
                      placeholder="e.g. ramesh@example.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-cream-300 bg-cream-50 text-sm focus:outline-none focus:border-forest-900"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-mono text-earth-700 block mb-1">Phone Number</label>
                  <input
                    type="tel"
                    placeholder="+91 91400 37160"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border border-cream-300 bg-cream-50 text-sm focus:outline-none focus:border-forest-900"
                  />
                </div>

                <div>
                  <label className="text-xs font-mono text-earth-700 block mb-1">Your Message</label>
                  <textarea
                    rows={4}
                    required
                    placeholder="Ask Abhay Jaiswal about daily mushroom delivery in Varanasi, restaurant bulk supply, or farm visits..."
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border border-cream-300 bg-cream-50 text-sm focus:outline-none focus:border-forest-900 resize-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-4 rounded-full bg-forest-950 hover:bg-forest-900 text-cream-50 font-bold text-xs uppercase tracking-widest flex items-center justify-center gap-2 shadow-xl transition-all"
                >
                  <Send className="w-4 h-4 text-golden-400" />
                  SEND MESSAGE
                </button>
              </form>
            )}
          </div>

        </div>

      </div>
    </div>
  );
};
