import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, CheckCircle2, ShieldCheck, Truck, CreditCard, Banknote } from 'lucide-react';
import { useCart } from '../../context/CartContext';
import { useToast } from '../../context/ToastContext';

interface CheckoutModalProps {
  onClose: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({ onClose }) => {
  const { cart, subtotal, clearCart } = useCart();
  const { addToast } = useToast();

  const [step, setStep] = useState<'details' | 'success'>('details');
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'upi' | 'card'>('cod');
  
  const [formData, setFormData] = useState({
    name: 'Gurpreet Singh',
    email: 'gurpreet@example.com',
    phone: '+91 98765 43210',
    address: 'House No 142, Sector 70, Mohali',
    city: 'Mohali',
    pincode: '160071',
  });

  const deliveryFee = subtotal > 499 || subtotal === 0 ? 0 : 50;
  const grandTotal = subtotal + deliveryFee;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('success');
    addToast('Order Placed Successfully!', 'Your fresh mushrooms are being prepared for dispatch.', 'success');
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={step === 'success' ? () => { clearCart(); onClose(); } : onClose}
          className="fixed inset-0 bg-forest-950/85 backdrop-blur-md"
        />

        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative w-full max-w-2xl bg-cream-50 rounded-3xl shadow-2xl border border-cream-200 overflow-hidden z-10 p-6 sm:p-8 max-h-[90vh] overflow-y-auto text-earth-900"
        >
          <button
            onClick={step === 'success' ? () => { clearCart(); onClose(); } : onClose}
            className="absolute top-4 right-4 p-2 rounded-full hover:bg-cream-200 text-earth-700 transition-colors"
            aria-label="Close checkout"
          >
            <X className="w-5 h-5" />
          </button>

          {step === 'details' ? (
            <div>
              <div className="flex items-center gap-3 border-b border-cream-200 pb-4 mb-6">
                <div className="w-10 h-10 rounded-full bg-forest-900 text-golden-400 flex items-center justify-center font-bold">
                  ✓
                </div>
                <div>
                  <h3 className="font-serif font-bold text-2xl text-forest-950">CHECKOUT & DELIVERY</h3>
                  <p className="text-xs text-earth-700 font-mono">Baba Ji Farms Express Dispatch</p>
                </div>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                {/* CONTACT & SHIPPING FIELDS */}
                <div className="space-y-4">
                  <h4 className="font-serif font-bold text-sm text-forest-950 uppercase tracking-wider">
                    1. Shipping Information
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-mono text-earth-700 block mb-1">Full Name</label>
                      <input
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-cream-300 bg-cream-100/60 text-sm focus:outline-none focus:border-forest-900"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-mono text-earth-700 block mb-1">Phone Number</label>
                      <input
                        type="tel"
                        required
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-cream-300 bg-cream-100/60 text-sm focus:outline-none focus:border-forest-900"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-mono text-earth-700 block mb-1">Delivery Street Address</label>
                    <input
                      type="text"
                      required
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-cream-300 bg-cream-100/60 text-sm focus:outline-none focus:border-forest-900"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-mono text-earth-700 block mb-1">City / Region</label>
                      <input
                        type="text"
                        required
                        value={formData.city}
                        onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-cream-300 bg-cream-100/60 text-sm focus:outline-none focus:border-forest-900"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-mono text-earth-700 block mb-1">Pincode</label>
                      <input
                        type="text"
                        required
                        value={formData.pincode}
                        onChange={(e) => setFormData({ ...formData, pincode: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-cream-300 bg-cream-100/60 text-sm focus:outline-none focus:border-forest-900"
                      />
                    </div>
                  </div>
                </div>

                {/* PAYMENT METHOD */}
                <div className="space-y-3 pt-2">
                  <h4 className="font-serif font-bold text-sm text-forest-950 uppercase tracking-wider">
                    2. Select Payment Method
                  </h4>

                  <div className="grid grid-cols-3 gap-3">
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('cod')}
                      className={`p-3 rounded-2xl border flex flex-col items-center gap-1.5 transition-all text-xs font-semibold ${
                        paymentMethod === 'cod'
                          ? 'bg-forest-900 text-cream-50 border-golden-500 shadow-md'
                          : 'bg-cream-100 border-cream-300 text-earth-800'
                      }`}
                    >
                      <Banknote className="w-5 h-5" />
                      <span>Cash on Delivery</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setPaymentMethod('upi')}
                      className={`p-3 rounded-2xl border flex flex-col items-center gap-1.5 transition-all text-xs font-semibold ${
                        paymentMethod === 'upi'
                          ? 'bg-forest-900 text-cream-50 border-golden-500 shadow-md'
                          : 'bg-cream-100 border-cream-300 text-earth-800'
                      }`}
                    >
                      <Truck className="w-5 h-5" />
                      <span>UPI / QR</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setPaymentMethod('card')}
                      className={`p-3 rounded-2xl border flex flex-col items-center gap-1.5 transition-all text-xs font-semibold ${
                        paymentMethod === 'card'
                          ? 'bg-forest-900 text-cream-50 border-golden-500 shadow-md'
                          : 'bg-cream-100 border-cream-300 text-earth-800'
                      }`}
                    >
                      <CreditCard className="w-5 h-5" />
                      <span>Debit/Credit Card</span>
                    </button>
                  </div>
                </div>

                {/* SUMMARY BREAKDOWN */}
                <div className="bg-cream-200/60 p-4 rounded-2xl space-y-2 text-xs font-mono">
                  <div className="flex justify-between">
                    <span>Items ({cart.length})</span>
                    <span>₹{subtotal}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Delivery Charge</span>
                    <span>{deliveryFee === 0 ? 'FREE' : `₹${deliveryFee}`}</span>
                  </div>
                  <div className="flex justify-between text-base font-serif font-bold text-forest-950 pt-2 border-t border-cream-300">
                    <span>Total Amount</span>
                    <span>₹{grandTotal}</span>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-4 rounded-full bg-golden-500 hover:bg-golden-400 text-forest-950 font-bold text-xs uppercase tracking-widest shadow-golden-glow transition-all"
                >
                  PLACE FARM ORDER • ₹{grandTotal}
                </button>
              </form>
            </div>
          ) : (
            /* SUCCESS CONFIRMATION SCREEN */
            <div className="py-8 text-center space-y-6">
              <motion.div
                initial={{ scale: 0.5, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="w-20 h-20 mx-auto rounded-full bg-forest-900 text-golden-400 flex items-center justify-center shadow-golden-glow"
              >
                <CheckCircle2 className="w-12 h-12" />
              </motion.div>

              <div>
                <span className="text-xs text-golden-600 font-mono tracking-widest uppercase font-bold">
                  ORDER #BJF-2026-8894
                </span>
                <h2 className="font-serif text-3xl font-bold text-forest-950 mt-1">
                  ORDER PLACED WITH LOVE!
                </h2>
                <p className="text-xs text-earth-800/80 max-w-md mx-auto mt-2 font-sans">
                  Thank you, <span className="font-bold">{formData.name}</span>! Our morning harvesting team has received your order and will pack your fresh mushrooms in insulated eco-kraft boxes for express delivery to:
                </p>
                <p className="text-xs font-mono bg-cream-200/80 p-3 rounded-xl max-w-md mx-auto mt-3 text-forest-950">
                  {formData.address}, {formData.city} ({formData.pincode})
                </p>
              </div>

              {/* TIMELINE STATUS PREVIEW */}
              <div className="bg-forest-950 text-cream-50 p-6 rounded-2xl text-left space-y-4 max-w-md mx-auto">
                <h4 className="text-xs font-mono uppercase text-golden-400 font-semibold flex items-center gap-2">
                  <Truck className="w-4 h-4" /> Live Dispatch Status:
                </h4>
                <div className="space-y-2 text-xs">
                  <div className="flex items-center gap-2 text-golden-400 font-semibold">
                    <span className="w-2 h-2 rounded-full bg-golden-500 animate-ping" />
                    <span>Harvesting Fresh at Dawn (Active)</span>
                  </div>
                  <div className="flex items-center gap-2 opacity-50">
                    <span className="w-2 h-2 rounded-full bg-cream-300" />
                    <span>Cold Packing Bay</span>
                  </div>
                  <div className="flex items-center gap-2 opacity-50">
                    <span className="w-2 h-2 rounded-full bg-cream-300" />
                    <span>Out for Doorstep Delivery</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => {
                  clearCart();
                  onClose();
                }}
                className="px-8 py-3.5 rounded-full bg-forest-950 hover:bg-forest-900 text-cream-50 font-bold text-xs uppercase tracking-widest transition-all"
              >
                RETURN TO STORE
              </button>
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
