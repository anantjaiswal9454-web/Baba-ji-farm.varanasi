import React from 'react';
import { motion } from 'framer-motion';
import { SporeParticles } from '../components/common/SporeParticles';
import { PROCESS_STEPS } from '../data/processSteps';
import { ShieldCheck, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export const ProcessPage: React.FC = () => {
  const extendedSteps = [
    ...PROCESS_STEPS,
    {
      number: '06',
      title: 'COLD STORAGE & DISPATCH',
      subtitle: 'Maintained at 4°C Chill Line',
      description: 'Packaged boxes enter our 4°C cold bay prior to courier pickup, locking in natural crispness and preventing moisture degradation.',
      details: ['4°C temperature log tracking', 'Tamper-evident security seal', 'Batch timestamped'],
      image: '/assets/mix.jpg',
      iconName: 'Box',
    },
    {
      number: '07',
      title: 'DOORSTEP DELIVERY & CONSUMPTION',
      subtitle: 'Arrives Crisp & Kitchen Ready',
      description: 'Delivered in temperature-controlled vans directly to home kitchens, restaurants, and retail partners within 12 hours of harvest.',
      details: ['Guaranteed freshness upon delivery', 'Storage tips card included', 'Zero waste packaging'],
      image: '/assets/oyster.jpg',
      iconName: 'Truck',
    },
  ];

  return (
    <div className="min-h-screen bg-cream-50 text-earth-900 pt-24 pb-24">
      {/* HERO BANNER */}
      <section className="relative bg-forest-950 text-cream-50 py-24 overflow-hidden mb-16 border-b border-golden-500/20">
        <SporeParticles density={35} speed={1} />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center space-y-4">
          <span className="text-xs font-mono font-bold text-golden-400 tracking-widest uppercase">
            CULTIVATION & HARVESTING JOURNEY
          </span>
          <h1 className="font-serif text-4xl sm:text-6xl font-bold tracking-tight text-cream-50">
            OUR 7-STEP FARM PROCESS
          </h1>
          <p className="text-sm sm:text-base text-cream-200/80 max-w-2xl mx-auto font-sans leading-relaxed">
            From organic substrate sterilization to precision climate control and dawn hand picking, explore how Baba Ji Farms ensures unmatched quality.
          </p>
        </div>
      </section>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {extendedSteps.map((step, idx) => (
          <motion.div
            key={step.number}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.6 }}
            className={`grid grid-cols-1 md:grid-cols-12 gap-8 items-center bg-cream-100 p-8 rounded-3xl border border-cream-200 shadow-organic ${
              idx % 2 === 1 ? 'md:flex-row-reverse' : ''
            }`}
          >
            <div className="md:col-span-6 space-y-4">
              <div className="flex items-center gap-3">
                <span className="w-10 h-10 rounded-full bg-forest-900 text-golden-400 font-mono font-bold text-sm flex items-center justify-center">
                  {step.number}
                </span>
                <span className="text-xs font-mono uppercase text-earth-700 font-bold">
                  STAGE {step.number} OF 07
                </span>
              </div>

              <h3 className="font-serif text-2xl sm:text-3xl font-bold text-forest-950">
                {step.title}
              </h3>
              <p className="text-xs font-semibold text-golden-600 font-mono">
                "{step.subtitle}"
              </p>
              <p className="text-xs sm:text-sm text-earth-800/80 leading-relaxed font-sans">
                {step.description}
              </p>

              <ul className="space-y-1.5 pt-2">
                {step.details.map((d, dIdx) => (
                  <li key={dIdx} className="flex items-center gap-2 text-xs font-mono text-forest-900">
                    <ShieldCheck className="w-4 h-4 text-forest-700 shrink-0" />
                    <span>{d}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="md:col-span-6 aspect-[4/3] rounded-2xl overflow-hidden shadow-lg border border-cream-300">
              <img src={step.image} alt={step.title} className="w-full h-full object-cover" />
            </div>
          </motion.div>
        ))}

        <div className="text-center pt-8">
          <Link
            to="/store"
            className="inline-flex items-center gap-2 px-8 py-4 rounded-full bg-forest-950 text-cream-50 font-bold text-xs uppercase tracking-widest hover:bg-forest-900 transition-all shadow-xl"
          >
            <span>TASTE THE RESULT IN OUR STORE</span>
            <ArrowRight className="w-4 h-4 text-golden-400" />
          </Link>
        </div>
      </div>
    </div>
  );
};
