import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ShoppingBag, Compass, ChevronDown, Sparkles } from 'lucide-react';
import { SporeParticles } from '../common/SporeParticles';

export const HeroSection: React.FC = () => {
  return (
    <section className="relative min-h-screen w-full flex items-center justify-center overflow-hidden bg-forest-950 text-cream-50 pt-24 pb-16">
      {/* BACKGROUND IMAGE WITH CINEMATIC OVERLAY */}
      <div className="absolute inset-0 z-0">
        <img
          src="/assets/hero.jpg"
          alt="Cinematic Organic Mushroom Farm"
          className="w-full h-full object-cover object-center scale-105 animate-pulse-subtle filter brightness-75"
        />
        {/* Dark emerald gradient overlay for absolute text readability */}
        <div className="absolute inset-0 bg-gradient-to-t from-forest-950 via-forest-950/75 to-forest-950/40" />
        <div className="absolute inset-0 bg-radial-vignette opacity-80" />
      </div>

      {/* SPORE & MIST PARTICLE CANVAS */}
      <SporeParticles density={45} speed={1.2} />

      {/* HERO CONTENT CONTAINER */}
      <div className="relative z-20 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center flex flex-col items-center">
        
        {/* MASCOT BRAND EMBLEM ENTRY ANIMATION */}
        <motion.div
          initial={{ opacity: 0, scale: 0.6, y: -20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
          className="relative mb-6"
        >
          <div className="w-20 h-20 md:w-28 md:h-28 rounded-full border-2 border-golden-500/60 p-1.5 bg-forest-900/80 shadow-golden-glow backdrop-blur-md">
            <img
              src="/assets/logo.jpg"
              alt="Baba Ji Mascot"
              className="w-full h-full object-cover rounded-full"
            />
          </div>
          <span className="absolute -top-1 -right-1 flex h-4 w-4">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-golden-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-4 w-4 bg-golden-500" />
          </span>
        </motion.div>

        {/* EYEBROW BADGE */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-forest-900/80 border border-golden-500/30 text-golden-400 text-xs md:text-sm font-semibold uppercase tracking-widest mb-6 backdrop-blur-sm"
        >
          <Sparkles className="w-4 h-4 text-golden-400 animate-spin" style={{ animationDuration: '6s' }} />
          BABA JI FARMS • 100% ORGANIC CULTIVATION
        </motion.div>

        {/* MAIN HEADLINE */}
        <motion.h1
          initial={{ opacity: 0, y: 25 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.5 }}
          className="text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-serif font-bold tracking-tight text-cream-50 leading-[1.08] max-w-4xl"
        >
          GROWN WITH CARE.{' '}
          <span className="block text-transparent bg-clip-text bg-gradient-to-r from-golden-400 via-cream-200 to-golden-500">
            DELIVERED WITH LOVE.
          </span>
        </motion.h1>

        {/* SUPPORTING SUBTITLE */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.7 }}
          className="mt-6 text-base sm:text-lg md:text-xl text-cream-200/90 max-w-2xl font-sans font-light leading-relaxed"
        >
          Fresh, highly nutritious mushrooms grown with careful organic cultivation and brought straight from our morning harvest to your kitchen.
        </motion.p>

        {/* CTA BUTTONS */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.9 }}
          className="mt-10 flex flex-col sm:flex-row items-center gap-4 w-full sm:w-auto"
        >
          <Link
            to="/store"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-3 px-8 py-4 rounded-full bg-golden-500 hover:bg-golden-400 text-forest-950 font-semibold text-sm tracking-wider uppercase shadow-golden-glow hover:scale-105 active:scale-95 transition-all duration-300 group"
          >
            <ShoppingBag className="w-5 h-5 group-hover:scale-110 transition-transform" />
            SHOP FRESH MUSHROOMS
          </Link>

          <Link
            to="/about"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-3 px-8 py-4 rounded-full bg-forest-900/80 hover:bg-forest-900 text-cream-50 font-semibold text-sm tracking-wider uppercase border border-golden-500/30 hover:border-golden-500/60 backdrop-blur-md hover:scale-105 active:scale-95 transition-all duration-300 group"
          >
            <Compass className="w-5 h-5 group-hover:rotate-45 transition-transform" />
            EXPLORE OUR FARM
          </Link>
        </motion.div>

      </div>

      {/* SCROLL INDICATOR */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2, duration: 1 }}
        className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-2 cursor-pointer"
        onClick={() => {
          window.scrollTo({ top: window.innerHeight * 0.9, behavior: 'smooth' });
        }}
      >
        <span className="text-[10px] uppercase font-mono tracking-widest text-golden-400/80">
          SCROLL TO EXPLORE
        </span>
        <motion.div
          animate={{ y: [0, 6, 0] }}
          transition={{ repeat: Infinity, duration: 1.8, ease: 'easeInOut' }}
          className="p-1.5 rounded-full border border-golden-500/40 text-golden-400 bg-forest-900/60 backdrop-blur-sm"
        >
          <ChevronDown className="w-4 h-4" />
        </motion.div>
      </motion.div>
    </section>
  );
};
