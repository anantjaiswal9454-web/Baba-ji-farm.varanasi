import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Star, ShoppingBag, Heart, ShieldCheck } from 'lucide-react';
import { Product } from '../../types';
import { useCart } from '../../context/CartContext';
import { useWishlist } from '../../context/WishlistContext';

interface QuickViewModalProps {
  product: Product;
  onClose: () => void;
}

export const QuickViewModal: React.FC<QuickViewModalProps> = ({ product, onClose }) => {
  const { addToCart } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();
  const [selectedWeight, setSelectedWeight] = useState(product.defaultWeight);
  const [quantity, setQuantity] = useState(1);

  const isLiked = isInWishlist(product.id);
  const currentWeightObj = product.weights.find((w) => w.weight === selectedWeight) || product.weights[0];
  const unitPrice = Math.round(product.price * currentWeightObj.priceMultiplier);
  const totalPrice = unitPrice * quantity;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
        {/* BACKDROP */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-forest-950/80 backdrop-blur-md"
        />

        {/* MODAL CONTENT */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ type: 'spring', damping: 25, stiffness: 250 }}
          className="relative w-full max-w-3xl bg-cream-50 rounded-3xl shadow-2xl border border-cream-200 overflow-hidden z-10 grid grid-cols-1 md:grid-cols-2 max-h-[90vh] overflow-y-auto"
        >
          {/* CLOSE BUTTON */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 z-20 p-2 rounded-full bg-forest-950/70 hover:bg-forest-950 text-cream-50 transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>

          {/* IMAGE */}
          <div className="relative aspect-square md:aspect-auto bg-cream-100">
            <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
            <div className="absolute bottom-4 left-4 right-4 p-3 bg-forest-950/80 backdrop-blur-sm rounded-xl text-cream-50 text-xs flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-golden-400 shrink-0" />
              <span>{product.farmDetails}</span>
            </div>
          </div>

          {/* DETAILS */}
          <div className="p-6 md:p-8 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between text-xs text-earth-700 font-mono uppercase mb-2">
                <span>{product.category}</span>
                <div className="flex items-center gap-1 text-golden-600 font-semibold">
                  <Star className="w-3.5 h-3.5 fill-golden-500 text-golden-500" />
                  <span>{product.rating}</span>
                </div>
              </div>

              <h2 className="font-serif text-2xl font-bold text-forest-950">{product.name}</h2>
              <p className="text-xs text-earth-800/80 mt-2 leading-relaxed font-sans">
                {product.shortDescription}
              </p>

              {/* WEIGHT SELECTOR */}
              <div className="mt-6">
                <label className="text-xs font-mono text-earth-700 uppercase tracking-wider block mb-2 font-semibold">
                  Select Weight Option:
                </label>
                <div className="flex flex-wrap gap-2">
                  {product.weights.map((w) => (
                    <button
                      key={w.weight}
                      onClick={() => setSelectedWeight(w.weight)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                        selectedWeight === w.weight
                          ? 'bg-forest-900 text-cream-50 shadow-md'
                          : 'bg-cream-200/70 text-earth-900 hover:bg-cream-200'
                      }`}
                    >
                      {w.weight}
                    </button>
                  ))}
                </div>
              </div>

              {/* QUANTITY COUNTER */}
              <div className="mt-6 flex items-center justify-between">
                <span className="text-xs font-mono text-earth-700 uppercase font-semibold">Quantity:</span>
                <div className="flex items-center border border-cream-300 rounded-full bg-cream-100 overflow-hidden">
                  <button
                    onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                    className="px-3 py-1 text-sm font-bold text-forest-950 hover:bg-cream-200"
                  >
                    -
                  </button>
                  <span className="px-4 text-xs font-bold font-mono text-forest-950">{quantity}</span>
                  <button
                    onClick={() => setQuantity((q) => q + 1)}
                    className="px-3 py-1 text-sm font-bold text-forest-950 hover:bg-cream-200"
                  >
                    +
                  </button>
                </div>
              </div>
            </div>

            {/* FOOTER ACTION */}
            <div className="mt-8 pt-4 border-t border-cream-200">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <span className="text-[10px] text-earth-700 font-mono block uppercase">Total Price</span>
                  <span className="font-serif text-2xl font-bold text-forest-950">₹{totalPrice}</span>
                </div>
                <button
                  onClick={() => toggleWishlist(product)}
                  className="p-2.5 rounded-full border border-cream-300 hover:bg-cream-200 text-forest-950 transition-colors"
                >
                  <Heart className={`w-5 h-5 ${isLiked ? 'fill-red-500 text-red-500' : ''}`} />
                </button>
              </div>

              <button
                onClick={() => {
                  addToCart(product, selectedWeight, quantity);
                  onClose();
                }}
                className="w-full py-3.5 rounded-full bg-golden-500 hover:bg-golden-400 text-forest-950 font-bold text-xs uppercase tracking-widest flex items-center justify-center gap-2 shadow-golden-glow transition-all"
              >
                <ShoppingBag className="w-4 h-4" />
                ADD TO BASKET
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
