import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

export const LoadingScreen: React.FC = () => {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1800);

    return () => clearTimeout(timer);
  }, []);

  return (
    <AnimatePresence>
      {isLoading && (
        <motion.div
          key="loader"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { duration: 0.8, ease: 'easeInOut' } }}
          className="fixed inset-0 z-[9999] bg-forest-950 flex flex-col items-center justify-center p-6 text-center"
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.6 }}
            className="relative mb-6"
          >
            <div className="w-24 h-24 md:w-32 md:h-32 rounded-full border-2 border-golden-500/30 p-2 flex items-center justify-center bg-forest-900 shadow-golden-glow">
              <img
                src="/assets/logo.jpg"
                alt="Baba Ji Farms Logo"
                className="w-full h-full object-cover rounded-full"
              />
            </div>
            {/* Animated pulse ring */}
            <span className="absolute inset-0 rounded-full border border-golden-500 animate-ping opacity-25" />
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="text-xl md:text-2xl font-serif tracking-widest text-cream-100 font-bold uppercase"
          >
            BABA JI FARMS
          </motion.h2>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="mt-3 text-xs md:text-sm text-golden-500 font-mono tracking-widest uppercase flex items-center gap-2"
          >
            <span className="w-2 h-2 rounded-full bg-golden-500 animate-pulse" />
            Grown With Care • Delivered With Love
          </motion.p>

          <div className="w-48 h-1 bg-forest-800 rounded-full mt-8 overflow-hidden relative">
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: '100%' }}
              transition={{ repeat: Infinity, duration: 1.4, ease: 'easeInOut' }}
              className="w-full h-full bg-gradient-to-r from-transparent via-golden-500 to-transparent"
            />
          </div>

          <p className="mt-4 text-xs text-cream-200/50 uppercase tracking-widest">
            GROWING SOMETHING GOOD...
          </p>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
