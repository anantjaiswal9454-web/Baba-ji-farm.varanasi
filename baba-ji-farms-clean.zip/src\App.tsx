import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation, useNavigate } from 'react-router-dom';
import { ToastProvider } from './context/ToastContext';
import { CartProvider } from './context/CartContext';
import { WishlistProvider } from './context/WishlistContext';
import { LoadingScreen } from './components/common/LoadingScreen';
import { ToastNotification } from './components/common/ToastNotification';
import { Navbar } from './components/layout/Navbar';
import { MobileMenu } from './components/layout/MobileMenu';
import { Footer } from './components/layout/Footer';
import { CartDrawer } from './components/cart/CartDrawer';
import { HomePage } from './pages/HomePage';
import { StorePage } from './pages/StorePage';
import { ProductDetailPage } from './pages/ProductDetailPage';
import { WishlistPage } from './pages/WishlistPage';
import { CartPage } from './pages/CartPage';
import { AboutPage } from './pages/AboutPage';
import { ProcessPage } from './pages/ProcessPage';
import { ContactPage } from './pages/ContactPage';
import { AccountPage } from './pages/AccountPage';
import { Search, X, ArrowRight } from 'lucide-react';
import { MOCK_PRODUCTS } from './data/products';

// Scroll to top component on route change
const ScrollToTop: React.FC = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

// Global Search Overlay Component
const SearchModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  const [query, setQuery] = useState('');
  const navigate = useNavigate();

  if (!isOpen) return null;

  const results = query.trim()
    ? MOCK_PRODUCTS.filter(
        (p) =>
          p.name.toLowerCase().includes(query.toLowerCase()) ||
          p.category.toLowerCase().includes(query.toLowerCase())
      )
    : [];

  return (
    <div className="fixed inset-0 z-[200] flex items-start justify-center pt-24 px-4 bg-forest-950/85 backdrop-blur-md">
      <div className="w-full max-w-2xl bg-cream-50 rounded-3xl p-6 shadow-2xl border border-cream-200 relative text-earth-900">
        <button onClick={onClose} className="absolute top-4 right-4 p-2 text-earth-700 hover:text-earth-900">
          <X className="w-5 h-5" />
        </button>

        <div className="relative mb-6">
          <Search className="w-5 h-5 absolute left-4 top-1/2 -translate-y-1/2 text-earth-700" />
          <input
            type="text"
            autoFocus
            placeholder="Search Oyster, White Button, Milky, Selection Box..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3.5 rounded-full border border-cream-300 bg-cream-100 text-sm font-sans focus:outline-none focus:border-forest-900"
          />
        </div>

        {results.length > 0 ? (
          <div className="space-y-3 max-h-80 overflow-y-auto">
            {results.map((product) => (
              <div
                key={product.id}
                onClick={() => {
                  navigate(`/product/${product.id}`);
                  onClose();
                }}
                className="p-3 bg-cream-100/60 rounded-2xl border border-cream-200 flex items-center justify-between hover:bg-cream-200 cursor-pointer transition-colors"
              >
                <div className="flex items-center gap-3">
                  <img src={product.image} alt={product.name} className="w-12 h-12 rounded-xl object-cover" />
                  <div>
                    <h4 className="font-serif font-bold text-sm text-forest-950">{product.name}</h4>
                    <span className="text-xs text-earth-700 font-mono">₹{product.price} / {product.defaultWeight}</span>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-forest-900" />
              </div>
            ))}
          </div>
        ) : query ? (
          <p className="text-center text-xs text-earth-700 py-8">No mushrooms matching "{query}"</p>
        ) : (
          <div className="text-xs text-earth-700 font-mono">
            <span className="block font-bold text-forest-950 mb-2">Popular Searches:</span>
            <div className="flex gap-2">
              {['Oyster', 'Button', 'Milky', 'Selection Box'].map((term) => (
                <button
                  key={term}
                  onClick={() => setQuery(term)}
                  className="px-3 py-1 bg-cream-200 rounded-full hover:bg-cream-300 text-forest-900 font-semibold"
                >
                  {term}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export const AppContent: React.FC = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col justify-between relative bg-cream-50">
      <ScrollToTop />
      <LoadingScreen />
      <ToastNotification />

      <Navbar
        onOpenMobileMenu={() => setIsMobileMenuOpen(true)}
        onOpenSearch={() => setIsSearchOpen(true)}
      />

      <MobileMenu
        isOpen={isMobileMenuOpen}
        onClose={() => setIsMobileMenuOpen(false)}
      />

      <CartDrawer />
      <SearchModal isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />

      <div className="flex-1">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/store" element={<StorePage />} />
          <Route path="/product/:id" element={<ProductDetailPage />} />
          <Route path="/wishlist" element={<WishlistPage />} />
          <Route path="/cart" element={<CartPage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/process" element={<ProcessPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/account" element={<AccountPage />} />
        </Routes>
      </div>

      <Footer />
    </div>
  );
};

export const App: React.FC = () => {
  return (
    <Router>
      <ToastProvider>
        <WishlistProvider>
          <CartProvider>
            <AppContent />
          </CartProvider>
        </WishlistProvider>
      </ToastProvider>
    </Router>
  );
};

export default App;
