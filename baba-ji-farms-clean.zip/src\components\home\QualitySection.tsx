import React from 'react';
import { motion } from 'framer-motion';
import { ShieldCheck, Sparkles, Droplets, PackageCheck } from 'lucide-react';

export const QualitySection: React.FC = () => {
  const pillars = [
    {
      title: 'Freshly Harvested',
      desc: 'Picked at dawn when cell density and moisture are peak, ensuring maximum umami and tender bite.',
      icon: Droplets,
    },
    {
      title: 'Carefully Packed',
      desc: 'Placed in breathable eco-kraft containers to prevent sogginess and maintain natural fragrance.',
      icon: PackageCheck,
    },
    {
      title: 'Farm Grown',
      desc: 'Cultivated in pure organic straw substrate with automated mountain misting and zero chemicals.',
      icon: ShieldCheck,
    },
  ];

  return (
    <section className="py-24 bg-forest-950 text-cream-50 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-forest-900 text-golden-400 text-xs font-mono font-semibold uppercase tracking-widest border border-golden-500/20 mb-4">
            <Sparkles className="w-3.5 h-3.5" />
            UNCOMPROMISING QUALITY
          </span>
          <h2 className="text-4xl sm:text-6xl font-serif font-bold text-cream-50 tracking-tight leading-tight">
            FROM OUR FARM.{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-golden-400 to-cream-200 block">
              TO YOUR TABLE.
            </span>
          </h2>
        </div>

        {/* 3 QUALITY CARDS */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {pillars.map((pillar, idx) => {
            const Icon = pillar.icon;
            return (
              <motion.div
                key={pillar.title}
                initial={{ opacity: 0, y: 25 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.6, delay: idx * 0.15 }}
                className="bg-forest-900/80 backdrop-blur-md rounded-3xl p-8 border border-golden-500/20 shadow-2xl flex flex-col justify-between hover:border-golden-500/50 transition-all duration-300 group"
              >
                <div>
                  <div className="w-14 h-14 rounded-2xl bg-forest-800 border border-golden-500/30 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                    <Icon className="w-7 h-7 text-golden-400" />
                  </div>
                  <h3 className="text-2xl font-serif font-bold text-cream-50 mb-3">
                    {pillar.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-cream-200/80 leading-relaxed font-sans">
                    {pillar.desc}
                  </p>
                </div>

                <div className="mt-8 pt-4 border-t border-forest-800 text-[11px] font-mono text-golden-500/70 uppercase tracking-widest">
                  100% Certified Organic Standard
                </div>
              </motion.div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
