import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ShoppingBag, Trash2, ArrowRight, ShieldCheck, Truck } from 'lucide-react';
import { useCart } from '../../context/CartContext';
import { CheckoutModal } from './CheckoutModal';

export const CartDrawer: React.FC = () => {
  const { cart, isCartOpen, setIsCartOpen, removeFromCart, updateQuantity, subtotal, totalItems } = useCart();
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);

  const deliveryFee = subtotal > 499 || subtotal === 0 ? 0 : 50;
  const grandTotal = subtotal + deliveryFee;

  return (
    <>
      <AnimatePresence>
        {isCartOpen && (
          <>
            {/* BACKDROP */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCartOpen(false)}
              className="fixed inset-0 z-[100] bg-forest-950/80 backdrop-blur-sm"
            />

            {/* DRAWER */}
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 250 }}
              className="fixed top-0 right-0 bottom-0 w-full max-w-md z-[101] bg-cream-50 text-earth-900 flex flex-col justify-between p-6 shadow-2xl border-l border-cream-200"
            >
              {/* DRAWER HEADER */}
              <div>
                <div className="flex items-center justify-between border-b border-cream-200 pb-4 mb-6">
                  <div className="flex items-center gap-2">
                    <ShoppingBag className="w-5 h-5 text-forest-900" />
                    <h3 className="font-serif font-bold text-xl text-forest-950">YOUR BASKET</h3>
                    <span className="px-2 py-0.5 rounded-full bg-forest-900 text-cream-50 text-xs font-mono font-bold">
                      {totalItems}
                    </span>
                  </div>
                  <button
                    onClick={() => setIsCartOpen(false)}
                    className="p-2 rounded-full hover:bg-cream-200 text-earth-700 transition-colors"
                    aria-label="Close basket"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* FREE SHIPPING PROGRESS BAR */}
                <div className="bg-cream-200/70 p-3 rounded-xl mb-6 text-xs text-earth-800 flex flex-col gap-1.5">
                  <div className="flex items-center justify-between font-semibold">
                    <span className="flex items-center gap-1.5">
                      <Truck className="w-4 h-4 text-forest-700" />
                      {subtotal >= 500 ? 'Free Farm Delivery Unlocked!' : `Add ₹${500 - subtotal} for FREE Delivery`}
                    </span>
                    <span className="font-mono text-[10px]">{Math.min(100, Math.round((subtotal / 500) * 100))}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-cream-300 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-forest-700 transition-all duration-300"
                      style={{ width: `${Math.min(100, (subtotal / 500) * 100)}%` }}
                    />
                  </div>
                </div>

                {/* CART ITEMS LIST */}
                {cart.length === 0 ? (
                  <div className="py-16 text-center space-y-4">
                    <div className="w-16 h-16 mx-auto rounded-full bg-cream-200 flex items-center justify-center text-earth-700 opacity-60">
                      <ShoppingBag className="w-8 h-8" />
                    </div>
                    <p className="font-serif text-lg font-bold text-forest-950">Your basket is empty</p>
                    <p className="text-xs text-earth-700 max-w-xs mx-auto">
                      Explore our daily harvest of organic Pearl Oyster, White Button, and Gourmet Mixes.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4 max-h-[50vh] overflow-y-auto pr-1">
                    {cart.map((item) => (
                      <div
                        key={`${item.product.id}-${item.selectedWeight}`}
                        className="p-3 bg-cream-100 rounded-2xl border border-cream-200/80 flex items-center gap-3"
                      >
                        <img
                          src={item.product.image}
                          alt={item.product.name}
                          className="w-16 h-16 object-cover rounded-xl shrink-0"
                        />

                        <div className="flex-1 min-w-0">
                          <h4 className="font-serif font-bold text-sm text-forest-950 truncate">
                            {item.product.name}
                          </h4>
                          <span className="text-[11px] text-earth-700 font-mono block">
                            Option: {item.selectedWeight} • ₹{item.unitPrice} each
                          </span>

                          <div className="flex items-center justify-between mt-2">
                            <div className="flex items-center border border-cream-300 rounded-full bg-cream-50 overflow-hidden">
                              <button
                                onClick={() => updateQuantity(item.product.id, item.selectedWeight, -1)}
                                className="px-2.5 py-0.5 text-xs font-bold hover:bg-cream-200"
                              >
                                -
                              </button>
                              <span className="px-2 text-xs font-bold font-mono">{item.quantity}</span>
                              <button
                                onClick={() => updateQuantity(item.product.id, item.selectedWeight, 1)}
                                className="px-2.5 py-0.5 text-xs font-bold hover:bg-cream-200"
                              >
                                +
                              </button>
                            </div>

                            <span className="font-serif font-bold text-sm text-forest-950">
                              ₹{item.unitPrice * item.quantity}
                            </span>
                          </div>
                        </div>

                        <button
                          onClick={() => removeFromCart(item.product.id, item.selectedWeight)}
                          className="p-1.5 text-earth-700/50 hover:text-red-500 transition-colors"
                          title="Remove item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* DRAWER FOOTER SUMMARY */}
              {cart.length > 0 && (
                <div className="pt-4 border-t border-cream-200 space-y-3">
                  <div className="flex items-center justify-between text-xs text-earth-800 font-mono">
                    <span>Subtotal</span>
                    <span className="font-bold">₹{subtotal}</span>
                  </div>
                  <div className="flex items-center justify-between text-xs text-earth-800 font-mono">
                    <span>Delivery Fee</span>
                    <span className="font-bold">{deliveryFee === 0 ? 'FREE' : `₹${deliveryFee}`}</span>
                  </div>
                  <div className="flex items-center justify-between text-base font-serif font-bold text-forest-950 pt-2 border-t border-cream-200">
                    <span>Grand Total</span>
                    <span className="text-xl">₹{grandTotal}</span>
                  </div>

                  <button
                    onClick={() => {
                      setIsCartOpen(false);
                      setIsCheckoutOpen(true);
                    }}
                    className="w-full py-4 rounded-full bg-forest-950 hover:bg-forest-900 text-cream-50 font-bold text-xs uppercase tracking-widest flex items-center justify-center gap-2 shadow-xl hover:scale-[1.02] active:scale-98 transition-all"
                  >
                    <span>PROCEED TO CHECKOUT</span>
                    <ArrowRight className="w-4 h-4 text-golden-400" />
                  </button>

                  <div className="flex items-center justify-center gap-1.5 text-[10px] text-earth-700 font-mono">
                    <ShieldCheck className="w-3.5 h-3.5 text-forest-700" />
                    <span>Safe & Organic Doorstep Delivery</span>
                  </div>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* CHECKOUT MODAL */}
      {isCheckoutOpen && <CheckoutModal onClose={() => setIsCheckoutOpen(false)} />}
    </>
  );
};
