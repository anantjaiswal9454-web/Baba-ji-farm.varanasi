import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ShoppingBag, Sparkles } from 'lucide-react';
import { SporeParticles } from '../common/SporeParticles';

export const FinalCTA: React.FC = () => {
  return (
    <section className="relative py-28 bg-forest-950 text-cream-50 overflow-hidden">
      {/* BACKGROUND IMAGE & OVERLAY */}
      <div className="absolute inset-0 z-0">
        <img
          src="/assets/hero.jpg"
          alt="Baba Ji Farms Visual CTA"
          className="w-full h-full object-cover filter brightness-50"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-forest-950 via-forest-950/80 to-forest-950/60" />
      </div>

      <SporeParticles density={30} speed={1} />

      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-8">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <div className="w-16 h-16 mx-auto mb-6 rounded-full border border-golden-500/40 p-1 bg-forest-900/80 shadow-golden-glow">
            <img src="/assets/logo.jpg" alt="Mascot Logo" className="w-full h-full object-cover rounded-full" />
          </div>

          <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-forest-900/90 text-golden-400 text-xs font-mono font-semibold uppercase tracking-widest border border-golden-500/30">
            <Sparkles className="w-3.5 h-3.5" />
            HARVEST DISPATCHED DAILY
          </span>
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="text-4xl sm:text-6xl font-serif font-bold text-cream-50 tracking-tight leading-tight"
        >
          BRING FARM-FRESH GOODNESS{' '}
          <span className="block text-transparent bg-clip-text bg-gradient-to-r from-golden-400 via-cream-200 to-golden-500">
            TO YOUR TABLE.
          </span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.4 }}
          className="text-base sm:text-lg text-cream-200/80 max-w-xl mx-auto font-sans"
        >
          Discover fresh, highly nutritious mushrooms grown with authentic care and brought straight from our organic farm to your kitchen.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.6 }}
          className="pt-4"
        >
          <Link
            to="/store"
            className="inline-flex items-center gap-3 px-10 py-5 rounded-full bg-golden-500 hover:bg-golden-400 text-forest-950 font-bold text-sm tracking-widest uppercase shadow-golden-glow hover:scale-105 active:scale-95 transition-all group"
          >
            <ShoppingBag className="w-5 h-5 group-hover:scale-110 transition-transform" />
            SHOP NOW
          </Link>
        </motion.div>
      </div>
    </section>
  );
};
