import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ShoppingBag, Trash2, ArrowRight, ShieldCheck, Truck, ArrowLeft } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { CheckoutModal } from '../components/cart/CheckoutModal';

export const CartPage: React.FC = () => {
  const { cart, removeFromCart, updateQuantity, subtotal, clearCart } = useCart();
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [promoCode, setPromoCode] = useState('');
  const [discount, setDiscount] = useState(0);

  const deliveryFee = subtotal > 499 || subtotal === 0 ? 0 : 50;
  const grandTotal = Math.max(0, subtotal - discount) + deliveryFee;

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    if (promoCode.trim().toUpperCase() === 'BABAJI10') {
      setDiscount(Math.round(subtotal * 0.1));
    } else if (promoCode.trim().toUpperCase() === 'FRESH50') {
      setDiscount(50);
    } else {
      alert('Invalid Promo Code. Try BABAJI10 for 10% off!');
    }
  };

  return (
    <div className="min-h-screen bg-cream-50 text-earth-900 pt-28 pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="flex items-center justify-between border-b border-cream-200 pb-6 mb-8">
          <div>
            <span className="text-xs font-mono font-bold tracking-widest text-golden-600 uppercase">
              SHOPPING BASKET
            </span>
            <h1 className="font-serif text-3xl sm:text-4xl font-bold text-forest-950">
              YOUR CART ITEMS ({cart.length})
            </h1>
          </div>
          <Link to="/store" className="text-xs font-mono font-bold text-forest-900 flex items-center gap-1 hover:underline">
            <ArrowLeft className="w-4 h-4" /> Continue Shopping
          </Link>
        </div>

        {cart.length === 0 ? (
          <div className="py-20 text-center bg-cream-100/70 rounded-3xl border border-cream-200 max-w-xl mx-auto p-8 space-y-6">
            <div className="w-20 h-20 mx-auto rounded-full bg-cream-200 flex items-center justify-center text-forest-900">
              <ShoppingBag className="w-10 h-10" />
            </div>
            <h3 className="font-serif text-2xl font-bold text-forest-950">Your basket is currently empty</h3>
            <p className="text-xs text-earth-800/80">Add fresh organic mushrooms from our store.</p>
            <Link
              to="/store"
              className="inline-flex items-center gap-2 px-8 py-4 rounded-full bg-forest-950 text-cream-50 font-bold text-xs uppercase tracking-widest hover:bg-forest-900 transition-all shadow-xl"
            >
              <span>GO TO STORE</span>
              <ArrowRight className="w-4 h-4 text-golden-400" />
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            {/* ITEMS LIST */}
            <div className="lg:col-span-8 space-y-4">
              {cart.map((item) => (
                <div
                  key={`${item.product.id}-${item.selectedWeight}`}
                  className="p-4 sm:p-6 bg-cream-100 rounded-3xl border border-cream-200 flex items-center gap-4 shadow-organic"
                >
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-24 h-24 object-cover rounded-2xl shrink-0"
                  />

                  <div className="flex-1 min-w-0">
                    <h3 className="font-serif font-bold text-lg text-forest-950">{item.product.name}</h3>
                    <p className="text-xs text-earth-700 font-mono">Weight: {item.selectedWeight} • ₹{item.unitPrice} per unit</p>

                    <div className="flex items-center justify-between mt-4">
                      <div className="flex items-center border border-cream-300 rounded-full bg-cream-50 overflow-hidden">
                        <button
                          onClick={() => updateQuantity(item.product.id, item.selectedWeight, -1)}
                          className="px-3 py-1 font-bold text-sm hover:bg-cream-200"
                        >
                          -
                        </button>
                        <span className="px-3 font-mono font-bold text-xs">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.product.id, item.selectedWeight, 1)}
                          className="px-3 py-1 font-bold text-sm hover:bg-cream-200"
                        >
                          +
                        </button>
                      </div>

                      <span className="font-serif font-bold text-xl text-forest-950">
                        ₹{item.unitPrice * item.quantity}
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => removeFromCart(item.product.id, item.selectedWeight)}
                    className="p-2 text-earth-700 hover:text-red-500 transition-colors"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              ))}

              <button
                onClick={clearCart}
                className="text-xs font-mono text-red-600 hover:underline pt-2 block"
              >
                Clear Entire Basket
              </button>
            </div>

            {/* ORDER SUMMARY SIDEBAR */}
            <div className="lg:col-span-4 bg-cream-100 rounded-3xl p-6 border border-cream-200 space-y-6 shadow-organic h-fit">
              <h3 className="font-serif font-bold text-xl text-forest-950 border-b border-cream-200 pb-4">
                SUMMARY
              </h3>

              {/* PROMO FORM */}
              <form onSubmit={handleApplyPromo} className="flex gap-2">
                <input
                  type="text"
                  placeholder="Promo Code (BABAJI10)"
                  value={promoCode}
                  onChange={(e) => setPromoCode(e.target.value)}
                  className="flex-1 px-3.5 py-2 rounded-xl border border-cream-300 bg-cream-50 text-xs font-mono"
                />
                <button type="submit" className="px-4 py-2 bg-forest-900 text-cream-50 rounded-xl text-xs font-bold uppercase">
                  Apply
                </button>
              </form>

              <div className="space-y-3 font-mono text-xs text-earth-800">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="font-bold">₹{subtotal}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-green-700 font-bold">
                    <span>Discount</span>
                    <span>-₹{discount}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Delivery Fee</span>
                  <span className="font-bold">{deliveryFee === 0 ? 'FREE' : `₹${deliveryFee}`}</span>
                </div>
                <div className="flex justify-between text-base font-serif font-bold text-forest-950 pt-3 border-t border-cream-200">
                  <span>Total Amount</span>
                  <span className="text-2xl">₹{grandTotal}</span>
                </div>
              </div>

              <button
                onClick={() => setIsCheckoutOpen(true)}
                className="w-full py-4 rounded-full bg-golden-500 hover:bg-golden-400 text-forest-950 font-bold text-xs uppercase tracking-widest shadow-golden-glow transition-all"
              >
                PROCEED TO CHECKOUT
              </button>
            </div>
          </div>
        )}

      </div>

      {isCheckoutOpen && <CheckoutModal onClose={() => setIsCheckoutOpen(false)} />}
    </div>
  );
};
