import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Heart, ShoppingBag, User, Menu, X } from 'lucide-react';
import { useCart } from '../../context/CartContext';
import { useWishlist } from '../../context/WishlistContext';

interface NavbarProps {
  onOpenMobileMenu: () => void;
  onOpenSearch: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenMobileMenu, onOpenSearch }) => {
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { totalItems, setIsCartOpen } = useCart();
  const { wishlistCount } = useWishlist();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'HOME', path: '/' },
    { name: 'STORE', path: '/store' },
    { name: 'ABOUT FARM', path: '/about' },
    { name: 'OUR PROCESS', path: '/process' },
    { name: 'CONTACT', path: '/contact' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'bg-forest-950/90 backdrop-blur-md py-3 shadow-xl border-b border-forest-800/40'
          : 'bg-gradient-to-b from-forest-950/80 via-forest-950/30 to-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        {/* LEFT: LOGO */}
        <Link to="/" className="flex items-center gap-3 group">
          <div className="relative w-10 h-10 md:w-12 md:h-12 rounded-full overflow-hidden border-2 border-golden-500/50 group-hover:border-golden-500 transition-colors shadow-md">
            <img
              src="/assets/logo.jpg"
              alt="Baba Ji Farms Mascot"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
          </div>
          <div className="flex flex-col">
            <span className="font-serif text-lg md:text-xl font-bold tracking-tight text-cream-50 leading-none group-hover:text-golden-400 transition-colors">
              BABA JI FARMS
            </span>
            <span className="text-[10px] md:text-[11px] tracking-widest text-golden-500 font-mono font-medium uppercase mt-0.5">
              FRESH • NATURAL • NUTRITIOUS
            </span>
          </div>
        </Link>

        {/* CENTER: DESKTOP NAV LINKS */}
        <nav className="hidden lg:flex items-center gap-8">
          {navLinks.map((link) => {
            const isActive = location.pathname === link.path;
            return (
              <Link
                key={link.name}
                to={link.path}
                className={`relative text-xs tracking-widest font-semibold uppercase transition-colors duration-200 py-1 ${
                  isActive ? 'text-golden-400' : 'text-cream-100/90 hover:text-golden-400'
                }`}
              >
                {link.name}
                {isActive && (
                  <motion.div
                    layoutId="activeNavIndicator"
                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-golden-500 rounded-full"
                    transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                  />
                )}
              </Link>
            );
          })}
        </nav>

        {/* RIGHT: ACTION ICONS */}
        <div className="flex items-center gap-2 sm:gap-4">
          {/* SEARCH BUTTON */}
          <button
            onClick={onOpenSearch}
            className="p-2 text-cream-100 hover:text-golden-400 transition-colors rounded-full hover:bg-forest-900/60 relative group"
            title="Search Products"
            aria-label="Search"
          >
            <Search className="w-5 h-5" />
            <span className="absolute -bottom-8 left-1/2 -translate-x-1/2 px-2 py-0.5 bg-forest-900 text-cream-100 text-[10px] rounded opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity font-mono">
              Search
            </span>
          </button>

          {/* WISHLIST BUTTON */}
          <Link
            to="/wishlist"
            className="p-2 text-cream-100 hover:text-golden-400 transition-colors rounded-full hover:bg-forest-900/60 relative group"
            title="View Wishlist"
            aria-label="Wishlist"
          >
            <Heart className="w-5 h-5" />
            {wishlistCount > 0 && (
              <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-golden-500 text-forest-950 text-[10px] font-bold flex items-center justify-center animate-pulse">
                {wishlistCount}
              </span>
            )}
            <span className="absolute -bottom-8 left-1/2 -translate-x-1/2 px-2 py-0.5 bg-forest-900 text-cream-100 text-[10px] rounded opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity font-mono">
              Wishlist
            </span>
          </Link>

          {/* CART BUTTON */}
          <button
            onClick={() => setIsCartOpen(true)}
            className="p-2 text-cream-100 hover:text-golden-400 transition-colors rounded-full hover:bg-forest-900/60 relative group"
            title="Open Basket"
            aria-label="Cart"
          >
            <ShoppingBag className="w-5 h-5" />
            {totalItems > 0 && (
              <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-golden-500 text-forest-950 text-[10px] font-bold flex items-center justify-center">
                {totalItems}
              </span>
            )}
            <span className="absolute -bottom-8 left-1/2 -translate-x-1/2 px-2 py-0.5 bg-forest-900 text-cream-100 text-[10px] rounded opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity font-mono">
              Cart
            </span>
          </button>

          {/* ACCOUNT BUTTON */}
          <Link
            to="/account"
            className="hidden sm:flex p-2 text-cream-100 hover:text-golden-400 transition-colors rounded-full hover:bg-forest-900/60 relative group"
            title="Customer Account"
            aria-label="Account"
          >
            <User className="w-5 h-5" />
            <span className="absolute -bottom-8 left-1/2 -translate-x-1/2 px-2 py-0.5 bg-forest-900 text-cream-100 text-[10px] rounded opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity font-mono">
              Account
            </span>
          </Link>

          {/* MOBILE MENU TOGGLE */}
          <button
            onClick={onOpenMobileMenu}
            className="lg:hidden p-2 text-cream-100 hover:text-golden-400 transition-colors rounded-lg hover:bg-forest-900/60 ml-1"
            aria-label="Open navigation menu"
          >
            <Menu className="w-6 h-6" />
          </button>
        </div>
      </div>
    </header>
  );
};
