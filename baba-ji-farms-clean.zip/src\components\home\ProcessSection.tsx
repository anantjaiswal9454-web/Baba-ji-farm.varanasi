import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { SectionHeading } from '../common/SectionHeading';
import { PROCESS_STEPS } from '../../data/processSteps';
import { Sprout, Wind, Hand, PackageCheck, Truck, ChevronRight } from 'lucide-react';

export const ProcessSection: React.FC = () => {
  const [activeStep, setActiveStep] = useState(0);

  const getIcon = (stepNumber: string) => {
    switch (stepNumber) {
      case '01': return Sprout;
      case '02': return Wind;
      case '03': return Hand;
      case '04': return PackageCheck;
      case '05': return Truck;
      default: return Sprout;
    }
  };

  return (
    <section className="py-24 bg-forest-950 text-cream-50 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <SectionHeading
          eyebrow="TRANSPARENT FARMING"
          title="FROM FARM TO TABLE"
          subtitle="Explore the 5 meticulous stages of organic cultivation, hand harvesting, and express cold-chain delivery."
          theme="dark"
        />

        {/* DESKTOP INTERACTIVE STORYTELLING PIPELINE */}
        <div className="hidden lg:block mt-16">
          {/* STEP TABS */}
          <div className="grid grid-cols-5 gap-4 mb-12 relative">
            {PROCESS_STEPS.map((step, idx) => {
              const Icon = getIcon(step.number);
              const isActive = activeStep === idx;
              return (
                <button
                  key={step.number}
                  onClick={() => setActiveStep(idx)}
                  className={`relative p-6 rounded-2xl border text-left transition-all duration-300 ${
                    isActive
                      ? 'bg-forest-900 border-golden-500 shadow-golden-glow translate-y-[-4px]'
                      : 'bg-forest-950/60 border-forest-800/60 hover:bg-forest-900/50 text-cream-200/60'
                  }`}
                >
                  <div className="flex items-center justify-between mb-4">
                    <span className="font-mono text-xs text-golden-400 font-bold">{step.number}</span>
                    <Icon className={`w-5 h-5 ${isActive ? 'text-golden-400' : 'text-forest-700'}`} />
                  </div>
                  <h4 className="font-serif font-bold text-sm text-cream-50 tracking-wider">
                    {step.title.split(' ')[0]} {step.title.split(' ')[1] || ''}
                  </h4>
                  <p className="text-[11px] text-cream-200/70 mt-1 line-clamp-1">{step.subtitle}</p>

                  {isActive && (
                    <motion.div
                      layoutId="activeStepBar"
                      className="absolute bottom-0 left-0 right-0 h-1 bg-golden-500 rounded-b-2xl"
                    />
                  )}
                </button>
              );
            })}
          </div>

          {/* ACTIVE STEP DISPLAY BOARD */}
          <motion.div
            key={activeStep}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="grid grid-cols-12 gap-8 items-center bg-forest-900/80 rounded-3xl p-8 border border-golden-500/20 shadow-2xl backdrop-blur-md"
          >
            <div className="col-span-6 space-y-6">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-forest-800 text-golden-400 text-xs font-mono font-semibold uppercase">
                STAGE {PROCESS_STEPS[activeStep].number} OF 05
              </div>

              <h3 className="text-3xl font-serif font-bold text-cream-50">
                {PROCESS_STEPS[activeStep].title}
              </h3>
              <p className="text-sm text-golden-400 font-medium">
                "{PROCESS_STEPS[activeStep].subtitle}"
              </p>
              <p className="text-sm text-cream-200/80 leading-relaxed font-sans">
                {PROCESS_STEPS[activeStep].description}
              </p>

              <ul className="space-y-2 pt-2">
                {PROCESS_STEPS[activeStep].details.map((detail, dIdx) => (
                  <li key={dIdx} className="flex items-center gap-2 text-xs text-cream-100 font-sans">
                    <span className="w-1.5 h-1.5 rounded-full bg-golden-500" />
                    <span>{detail}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="col-span-6 aspect-[4/3] rounded-2xl overflow-hidden shadow-2xl border border-forest-800">
              <img
                src={PROCESS_STEPS[activeStep].image}
                alt={PROCESS_STEPS[activeStep].title}
                className="w-full h-full object-cover"
              />
            </div>
          </motion.div>
        </div>

        {/* MOBILE VERTICAL STORYLINE TIMELINE */}
        <div className="lg:hidden mt-12 space-y-8">
          {PROCESS_STEPS.map((step) => {
            const Icon = getIcon(step.number);
            return (
              <motion.div
                key={step.number}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, margin: '-40px' }}
                className="bg-forest-900/90 p-6 rounded-2xl border border-golden-500/20 space-y-4"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-golden-500 text-forest-950 flex items-center justify-center font-mono font-bold text-sm">
                    {step.number}
                  </div>
                  <div>
                    <h4 className="font-serif font-bold text-base text-cream-50">{step.title}</h4>
                    <p className="text-xs text-golden-400">{step.subtitle}</p>
                  </div>
                </div>

                <div className="aspect-video rounded-xl overflow-hidden">
                  <img src={step.image} alt={step.title} className="w-full h-full object-cover" />
                </div>

                <p className="text-xs text-cream-200/80 leading-relaxed font-sans">{step.description}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
